--[[Use these values to initialise the OpenGL window]]--
PROGRAM_NAME = "C++ and Lua Script Testing for OpenGL"
PROGRAM_VERSION = "1.0"
SCREENWIDTH = 1024
SCREENHEIGHT = 800
COLORDEPTH = 32
FULLSCREEN = true

