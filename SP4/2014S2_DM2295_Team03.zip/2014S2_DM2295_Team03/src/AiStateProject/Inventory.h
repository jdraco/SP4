#pragma once

#define MAX_ITEM_SLOTS 20

#include "Function.h"

struct item
{
	int item_id, item_price;
	std::string item_name, item_description, item_description2;
	bool has_been_rendered, is_a_material, is_useable,
	is_discardable, is_equipped, is_new, is_selected_for_crafting;
};

class Inventory
{
private:
	enum item_list
	{
		EMPTY,
		BANDAGES,				// CONSUMABLE
		CLOTH,					// MATERIAL
		ALCOHOL,				// CONSUMABLE + MATERIAL
		MACHETE,				// EQUIPABLE
		BROKEN_WOODEN_HANDLE,	// MATERIAL
		BROKEN_BLADE,			// MATERIAL
		LOCKPICK,				// CONSUMABLE
		PISTOL,					// EQUIPABLE
		RIFLE					// EQUIPABLE
	};

	int num_of_items;
	item slot[MAX_ITEM_SLOTS];
	item crafting_slot[3];		// Crafting-slot 3 is a product slot (DO NOT ALLOW USER TO PLACE ANYTHING INSIDE)

	TextureImage item_tex[11], other_tex[1];
	void *font_style;

public:
	Inventory(void);
	~Inventory(void);

	void printw (float x, float y, float z, char* format, ...);

	void addItem(int item_no);
	bool addItem(int set,int item_id);
	void removeItem(int item_id);
	void removeItem(string item_name);
	bool findItem(int item_id);
	bool findItem(string item_name);
	
	void emptySlot(int slot_no);
	void emptyAllSlots();
	int getSlotItem(int slot_no);
	int getSlotPrice(int slot_no);
	string getSlotItemName(int slot_no);
	string getSlotItemDescription(int slot_no);
	string getSlotItemDescription2(int slot_no);
	bool getSlotItemUseableStatus(int slot_no);
	bool getSlotItemDiscardableStatus(int slot_no);
	bool getSlotItemEquippedStatus(int slot_no);
	bool getSlotItemSelectedForCraftingStatus(int slot_no);

	void clearAllEquippedStatus();
	void setNextSameItemToBeEquipped(string item_name);
	void setAllItemsToBeOld();
	void resetAllItemsSelectedForCrafting();


	void useSlotItem(int slot_no);

	void craftWithSlotItem(int slot_no);
	void resetCraftingSlots();
	bool attemptCrafting(void);

	void renderInventorySlot(int slot_no);
	void renderCraftingSlots();

	bool craft_in_first_slot;
};