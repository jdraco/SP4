#pragma once
#include "Goodies.h"
#include "Inventory.h"
#include "Weapon.h"

class CPlayerInfo;

class CGuard : public CGoodies 
{

private:
	CGameTime IdleTime; // Time state
	CGameTime AttackTime; // Time state

	//Store player info
	CPlayerInfo* Player;
	CSprite* GuardSprite;

	bool isMoving;
	bool NeedRender;

	bool heroAnimationInvert;
	int heroAnimationCounter;
	float previousTime;
	ISound*enemy;

	//sightchecking
	float range;			//Checking range
	float disp;				//how wide you want the check to be

	Vector3D mid;			//image middlepoint
	
	Vector3D dirPoint;		//dir point
	Vector3D leftPoint;		
	Vector3D rightPoint;

	Vector3D PlayerPos;
	TextureImage currIMG;
public:
	CGuard(void);
	~CGuard(void);

	//path point;
	CWayPoint OwnPath;
	void WayPointDir();

	short CurrentState;
	short PrevState;
	enum Playerstate 
	{
		IDLE = 0,
		ATTACK,
		CHASE,
		PATROL,
		RETREAT,
		COLLIDED_D,
		COLLIDED_U,
		COLLIDED_L,
		COLLIDED_R,
		STATE_TOTAL
	};

	void SelfInit(void) ;
	bool Update(void);
	void Render();

	void Info();
	void IndividualAction();
	//void TeamAction();
	int GetState();
	 void SetItem(ITEM_ID item_id , int SetItem);
	 int GetItem(ITEM_ID item_id);

	 //Get player info over
	 void SetTarget(CPlayerInfo* thePlayer) {Player = thePlayer;};
	  //set path for guard to walk
	 void SetPath(CWayPoint ownpath) { OwnPath = ownpath; } ;

	 //sightchecking
	 bool SightChecking();

	 Inventory *inventory;
	 CWeapon *weapon;
	 // CPlayerInfo GetTarget();
	 bool loot;
};

