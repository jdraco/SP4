#include "SecurityCam.h"


CSecurityCam::CSecurityCam(void)
{
}


CSecurityCam::~CSecurityCam(void)
{
}

void CSecurityCam::SelfInit(int type)
{
	m_iTileSize = TILE_SIZE;
	
	switch(type)
	{
	case 1:
	Dir = Vector3D(0.0f,-1.0f);
	LoadTGA(&Texture[0], "Texture/camerainvert.tga");
	range = 300;
	disp = 0.4;
	break;
	case 2:
	Dir = Vector3D(0.0f,1.0f);
	LoadTGA(&Texture[0], "Texture/camera.tga");
	range = 300;
	disp = 0.4;
	break;
	case 3:
	Dir = Vector3D(0.0f,-1.0f);
	LoadTGA(&Texture[0], "Texture/camerainvert.tga");
	range = 150;
	disp = 0.7;
	break;
	case 4:
	Dir = Vector3D(0.0f,1.0f);
	LoadTGA(&Texture[0], "Texture/camera.tga");
	range = 150;
	disp = 0.7;
	break;
	case 5://LEFT
	Dir = Vector3D(-1.0f,0.0f);
	LoadTGA(&Texture[0], "Texture/camerainvert.tga");
	range = 150;
	disp = 0.7;
	break;
	case 6://RIGHT
	Dir = Vector3D(1.0f,0.0f);
	LoadTGA(&Texture[0], "Texture/camera.tga");
	range = 100;
	disp = 0.2;
	break;
	}
	weapon = new CWeapon();
	weapon->Init();
	weapon->setCurrAmmo(-2);// inf ammo
	prevTime = 0;
}
	
bool CSecurityCam::Update(void)
{
	float dt = CGameTime::GetDelta();
	//cout << dt << endl;

	//decide whether to render or not
	if (Pos.x < LEFT_BORDER || Pos.x > RESOLUTION_WIDTH-LEFT_BORDER-TILE_SIZE*3 || 
		Pos.y < BOTTOM_BORDER || Pos.y > RESOLUTION_HEIGHT-BOTTOM_BORDER+TILE_SIZE)
	{
		NeedRender = false;
	}
	else
	{
		NeedRender = true;
	}

	//Vector3D Checkdir = Vector3D(1-Checkdisp,-1+Checkdisp); 
	mid =  Vector3D( (Pos.x + m_iTileSize*0.5) ,   (Pos.y  + m_iTileSize*0.5) );
	dirPoint = Vector3D( (mid.x + range* Dir.x) , (mid.y + range * Dir.y)  );

	//cout << Dir.x << " , " << Dir.y << endl;

	if(Dir.y > 0 && Dir.x > 0 ){ // +X , + Y (dir at top right corner)
		leftPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y + disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y + disp) )  );
		//cout << "bot right" << endl;
	}
	else if (Dir.y > 0 && Dir.x < 0) // -X , + Y (top left)
	{ 
		leftPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y + disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y - disp) )  );
		//cout << "bot left" << endl;
	}

	else if(Dir.y > 0 && Dir.x > 0 ){ // +X , -Y (dir at bot right corner)
		leftPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y - disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y - disp) )  );
		//cout << "top right" << endl;
	}
	else if (Dir.y > 0 && Dir.x < 0) // -X , + Y (bot left )
	{ 
		leftPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y - disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y + disp) )  );
	
		//cout << "top left" << endl;
	}


	if (Dir.y == -1 && Dir.x == 0) // -X , + Y (down)
	{ 
		leftPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y + disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y + disp) )  );
		//cout << "up" << endl;
	}
	else if(Dir.y == 1 && Dir.x == 0 ) // +X , + Y (up)
	{ 
		leftPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y - disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y - disp) )  );
		//cout << "down" << endl;
	}

	else if (Dir.y == 0 && Dir.x == -1) // -X , + Y (left)
	{
		leftPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y - disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y + disp) )  );
		//cout << "left" << endl;
	}
	else if (Dir.y == 0 && Dir.x == 1) // -X , + Y (right)
	{ 
		leftPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y + disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y - disp) )  );
	
		//cout << "right" << endl;
	}

	if( Vector3D::PointInTriangle(PlayerPos,mid,leftPoint,rightPoint) )
	{
		Color = Vector3D(GREEN);
		weapon->setCurrEquipped("Turret");
		weapon->Attack((PlayerPos-Pos).normalized(),Pos,false);
		AnimationCounter = -((PlayerPos-Pos).normalized().x+1)*4;
	}
	else
	{
		prevTime+=dt;
		Color = Vector3D(RED);
		if(prevTime > 1)
		{
			prevTime = 0;
			if(AnimationInvert)
			AnimationCounter--;
			else
			AnimationCounter++;
			if(AnimationCounter >= 7)
				AnimationInvert = true;
			if(AnimationCounter <= 1)
				AnimationInvert = false;
		
		}
	}

	
	if(Dir.x < 0)
		weapon->SetAnimationInvert( false );
	else
		weapon->SetAnimationInvert( true );

	weapon->SetPos_x(mid.x);
	weapon->SetPos_y(mid.y);

	return true;
}
	
void CSecurityCam::Render(void)
{
	glPushMatrix();
	weapon->Update();
	glColor3f(Color.x,Color.y,Color.z);

	if(NeedRender == true){
		//drawLines(mid,dirPoint); 
		drawLines(mid,leftPoint); 
		drawLines(mid,rightPoint); 
		drawLines(leftPoint,rightPoint); 
		glColor3f(1,1,1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
		glTranslatef(Pos.x,Pos.y, 0);
		glBindTexture( GL_TEXTURE_2D, Texture[0].texID );
		glBegin(GL_QUADS);
		
		/*if (Dir.x == -1)
		{
			glTexCoord2f(0.1428 * AnimationCounter,1); 
			glVertex2f(0,0);
			glTexCoord2f(0.1428 * AnimationCounter,0); 
			glVertex2f(0,m_iTileSize);
			glTexCoord2f(0.1428 * AnimationCounter + 0.1428,0); 
			glVertex2f(m_iTileSize,m_iTileSize);
			glTexCoord2f(0.1428 * AnimationCounter + 0.1428,1); 
			glVertex2f(m_iTileSize,0);
		}
		else
		{*/
			glTexCoord2f(0.1428 * AnimationCounter + 0.1428,1); 
			glVertex2f(0,0);
			glTexCoord2f(0.1428 * AnimationCounter + 0.1428,0); 
			glVertex2f(0,m_iTileSize);
			glTexCoord2f(0.1428 * AnimationCounter,0); 
			glVertex2f(m_iTileSize,m_iTileSize);
			glTexCoord2f(0.1428 * AnimationCounter,1); 
			glVertex2f(m_iTileSize,0);
		/*}*/
		
		glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
	}
	
	glPopMatrix();
}

void CSecurityCam::SetPlayerPos(Vector3D temp)
{
	PlayerPos = temp;
}