#pragma once
#include "Goodies.h"
#include "Weapon.h"

class CSecurityCam : public CVariable
{
private:
	float range;			//Checking range
	float disp;				//how wide you want the check to be
	//Vector3D Checkdir = Vector3D(1-Checkdisp,-1+Checkdisp); 
	Vector3D mid;			//image middlepoint
	
	Vector3D dirPoint;		//dir point
	Vector3D leftPoint;		
	Vector3D rightPoint;

	Vector3D PlayerPos;
	
	bool NeedRender;

	float prevTime;
public:
	CSecurityCam(void);
	~CSecurityCam(void);

	void SelfInit(int type);
	bool Update(void);
	void Render(void);

	CWeapon *weapon;
	void SetPlayerPos(Vector3D temp);
};

