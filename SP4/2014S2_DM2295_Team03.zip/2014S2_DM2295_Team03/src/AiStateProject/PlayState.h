#pragma once
#include "Map.h"
#include "weaponManager.h"
#include "Camera.h"
#include "GoodiesFactory.h"
#include "HUD.h"
#include "Font.h"

#include "GameState.h"
#include "GameEndState.h"
#define MAX_LEVEL 8

class CPlayer;
class CGuard;

class CPlayState : public CGameState
{
public:
	void Init();
	void Cleanup();

	void Pause();
	void Resume();

	void HandleEvents(CGameStateManager* theGSM);
	void Update(CGameStateManager* theGSM);
	void Draw(CGameStateManager* theGSM);

	static CPlayState* Instance() {
		return thePlayState;
	}

	
	
	// Goodies and Goodies Factory
	
	CGoodiesFactory* theGoodFactory;

	//Player
	CPlayerInfo *thePlayer;
	CweaponManager *weapManager;
	//vector<CGoodies*> GameObjList;

	//Guards
	vector<CGuard*> GuardList;
	//Security Cam
	vector<CSecurityCam*> SCamList;
	vector<DmgFont*> MoneyList;

	bool Debug;
	//Dispaly HUD
	HUD* hud;
	
	//Camera (not in use)
	Camera* theCamera;

	//global variable class
	CGlobal* theGlobal;

	//NPC
	CNpc *theNpc;

	//Path List
	CWayPoint Paths[ CMap::PATH_END - CMap::PATH_START -1 ];

	~CPlayState() {

		//thePlayer->myInventory.emptyAllSlots(); 
	};

	static CPlayState* NewInstance() {
		thePlayState = new CPlayState();
		return thePlayState;
	}
	/*static void DeleteInstance()
	{
		delete &thePlayState;
		thePlayState = new CPlayState();
	}*/

	bool game_pause;
	bool main_menu;

	int get_menu_volume();
	bool get_menu_sounds_muted();
protected:
	CPlayState() { }

private:
	CFont *font;
	static CPlayState * thePlayState;
	ISound*game;

	enum TEXTURES {
		LEFT,
		FRONT,
		RIGHT,
		BACK,
		TOP,
		BOTTOM,
		NUM_TEXTURES
	};
	
	//map rendering

	void LoadLevel(short level);
	short currentMap;

	//save last time
	float lastTime;
	int cubeCount;

	void RenderHud();

	void drawString();

	//makes players at the center point, and scrolls the other stuff
	void ConstrainPlayer(const int leftBorder, const int rightBorder, 
							  const int topBorder, const int bottomBorder, 
							  float timeDiff,
							  int& mapOffset_x, int& mapOffset_y);

	void ScanMap();
	ISound*sfx;
	void DebugInfo();

	void End(int tex , int end);
	TextureImage Tex[2];
	
	float CountDown;
	float CountDownWin;


	bool prevKey[255];
	float npcPos[MAX_LEVEL][2];
	void InitNpc();
};
