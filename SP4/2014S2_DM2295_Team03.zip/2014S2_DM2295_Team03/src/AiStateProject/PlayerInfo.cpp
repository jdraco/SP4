#include "PlayerInfo.h"
#include "Guard.h"
#include <fstream>

#define SPEED 5.0f
using namespace std;

CPlayerInfo* CPlayerInfo::_instance = 0;

CPlayerInfo*CPlayerInfo::getInstance()
{
	if (_instance == 0)
	{
		_instance = new CPlayerInfo;
	}
	return _instance;
}

CPlayerInfo::CPlayerInfo(void)
:IsPos(false)
,notification("")
,notificationTimer(0)
,playerSound(NULL)
,playerWalk(NULL)
{
	theGlobal = CGlobal::getInstance();
	Math::InitRNG();
}
CPlayerInfo::~CPlayerInfo(void)
{
}
// Initialise this class instance
void CPlayerInfo::Init(void)
{
	state = "default";
	m_iTileSize = TILE_SIZE;
	
	if( !LoadTGA( &(Texture[ 0 ]), "Texture/Tiles/James.tga"))
		cout << "No hero texture" << endl;
	if( !LoadTGA( &(Texture[ 1 ]), "Texture/Tiles/James.tga"))
		cout << "No hero texture" << endl;
	if( !LoadTGA( &(Texture[ 2 ]), "Texture/Tiles/Jamesup.tga"))
		cout << "No hero texture" << endl;
	if( !LoadTGA( &(Texture[ 3 ]), "Texture/Tiles/Jamesdown.tga"))
		cout << "No hero texture" << endl;
	
	//Init Position (Can be Lua-ed)
	//Pos = Vector3D(200,310,0);

	Money =	200;
	HP = 100;

	//Health and armor
	Health.max = 100;
	Health.current = Health.max;
	Damage = 1;		//can be change to weopen damage

	weapon = new CWeapon();
	//weapen = CWeapon::GetInstance();
	weapon->Init();

	myInventory = new Inventory();
	//inventory = new Inventory();
	myInventory->addItem(1);
	myInventory->addItem(2);
	myInventory->addItem(3);
	myInventory->addItem(5);
	myInventory->addItem(6);
	myInventory->addItem(7);
	
	curr_inv_weap = "NIL";

	font = new CFont();
}
/****************************************************************************************************
Draw the hero
****************************************************************************************************/
void CPlayerInfo::Render(void) {
	
	DrawHealthBar(Health.current, Health.max ,  Pos.x-110 ,Pos.y-20,Vector3D(0,1,0));
	
	if (isMoving == false)
	{
		if (GetAnimationCounter() != 0)
			SetAnimationCounter(0);
	}
	if(weapon->getCurrEquipped() != "NIL" && facingup)
	{
		weapon->SetPos_x(Pos.x);
		weapon->SetPos_y(Pos.y);
		weapon->Renderweap();
	}
	glPushMatrix();
	glTranslatef(Pos.x, Pos.y, 1);
	glEnable( GL_TEXTURE_2D );
	glEnable( GL_BLEND );
	//glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	if (facingup == false && facingdown == false)
		glBindTexture( GL_TEXTURE_2D, Texture[1].texID );
	else if (facingup == true && facingdown == false)
		glBindTexture( GL_TEXTURE_2D, Texture[2].texID );
	else if (facingup == false && facingdown == true)
		glBindTexture( GL_TEXTURE_2D, Texture[3].texID );
	glBegin(GL_QUADS);
	if (AnimationInvert == true)
	{
		glTexCoord2f(0.25 * AnimationCounter,1); 
		glVertex2f(0,0);
		glTexCoord2f(0.25 * AnimationCounter,0); 
		glVertex2f(0,m_iTileSize);
		glTexCoord2f(0.25 * AnimationCounter + 0.25,0); 
		glVertex2f(m_iTileSize,m_iTileSize);
		glTexCoord2f(0.25 * AnimationCounter + 0.25,1); 
		glVertex2f(m_iTileSize,0);
	}
	else
	{
		glTexCoord2f(0.25 * AnimationCounter + 0.25,1); 
		glVertex2f(0,0);
		glTexCoord2f(0.25 * AnimationCounter + 0.25,0); 
		glVertex2f(0,m_iTileSize);
		glTexCoord2f(0.25 * AnimationCounter,0); 
		glVertex2f(m_iTileSize,m_iTileSize);
		glTexCoord2f(0.25 * AnimationCounter,1); 
		glVertex2f(m_iTileSize,0);
	}
	glEnd();
	glDisable( GL_BLEND );
	glDisable( GL_TEXTURE_2D );
	glPopMatrix();
	if(weapon->getCurrEquipped() != "NIL" && !facingup)
	{
		weapon->SetPos_x(Pos.x);
		weapon->SetPos_y(Pos.y);
		weapon->Renderweap();
	}
	weapon->Update();
	//myInventory->renderInventorySlot(1);
	if(notificationTimer > 0)
	{
		font->Render(notification,Pos,Vector3D(1,1,0),1);
	}
	for(unsigned a = 0; a < DmgList.size(); ++a)
	{
		font->Render(DmgList[a]->DMG,DmgList[a]->Pos,DmgList[a]->col,DmgList[a]->size);
	}
}


void CPlayerInfo::keyboardUpdate()
{
	//Delta Time
	float dt = CGameTime::GetDelta();


	//Constrain Hero to middle of screen (unless he reaches the border)
	/*
	ConstrainHero((const int)(MAP_SCREEN_WIDTH*0.5+LEFT_BORDER), (const int)(MAP_SCREEN_WIDTH*0.5+LEFT_BORDER), 
					(const int)(MAP_SCREEN_HEIGHT*0.5+BOTTOM_BORDER), (const int)(MAP_SCREEN_HEIGHT*0.5+BOTTOM_BORDER),
					1.0f, theGlobal->theMap->mapOffset_x, theGlobal->theMap->mapOffset_y, 
					SCREEN_WIDTH, MAP_SCREEN_WIDTH, SCREEN_HEIGHT, MAP_SCREEN_HEIGHT);
					*/
	/*
	ConstrainPlayer((const int)(MAP_SCREEN_WIDTH*0.5+LEFT_BORDER), (const int)(MAP_SCREEN_WIDTH*0.5+LEFT_BORDER), 
					(const int)(MAP_SCREEN_HEIGHT*0.5+BOTTOM_BORDER), (const int)(MAP_SCREEN_HEIGHT*0.5+BOTTOM_BORDER),
					1.0f, theGlobal->theMap->mapOffset_x, theGlobal->theMap->mapOffset_y);
	*/

	//Vector3D Pos = Vector3D(hero_x,hero_y,0);
	//Check Collision to toggle effect
	theGlobal->CheckCollision(Pos, theGlobal->theMap, 
					theGlobal->theMap->mapOffset_x, theGlobal->theMap->mapOffset_y);

	//Determine Player Direction
	/*Vector3D playerDir;*/

	//Player is Jumping
	/*
	if (jump)
	{
		//++y pos
		pos.y += PLAYER_MOVEMENT_SPEED * CTimer::getInstance()->getDelta();
		CInputSystem::getInstance()->stopMovement = true;

		//Reset Jump
		if (playerJumpSprite->CurSubImage == PLAYER_JUMP_SUB-1)
			jump = CInputSystem::getInstance()->stopMovement = false;
	}
	*/
	//Check Collision of the player before moving Up
	if ((theGlobal->myKeys['w'] || theGlobal->myKeys['W']))
	{
		if (!theGlobal->CheckEntrance(Pos,theGlobal->theMap,theGlobal->theMap->mapOffset_x,theGlobal->theMap->mapOffset_y))
		{
		//Alter Player Direction
		if (!(theGlobal->myKeys['a'] && !theGlobal->myKeys['A']) 
			&& !(theGlobal->myKeys['d'] && !theGlobal->myKeys['D']))
		Dir.x = 0;
		Dir.y = -1;
		facingup = true;
		facingdown = false;

		SetAnimationCounter( GetAnimationCounter() - 1);
		if (GetAnimationCounter()==0)
			SetAnimationCounter( 3 );

		//Do not allow movement when stopMovement is true
		/*if (!theGlobal->myKeys['d'] && !theGlobal->myKeys['D']  && 
			!theGlobal->myKeys['a'] && !theGlobal->myKeys['A'])
		{*/
			//Check if Collision is detected
			if (!theGlobal->Collided(Pos-Vector3D(0,5,0), true, false, false, false, 
				theGlobal->theMap,theGlobal->theMap->mapOffset_x, theGlobal->theMap->mapOffset_y)
				&& !LR)
			{
				Pos.y =  Pos.y - (int) (SPEED *  1.0f) ;
				bMoving = true;
				Walk(true);
			}
		//}
		}
		
	}

	//Check Collision of the player before moving down
	if ((theGlobal->myKeys['s'] || theGlobal->myKeys['S']))
	{
		if (!theGlobal->CheckEntrance(Pos,theGlobal->theMap,theGlobal->theMap->mapOffset_x,theGlobal->theMap->mapOffset_y))
		{
		//Alter Player Direction
		if (!(theGlobal->myKeys['a'] && !theGlobal->myKeys['A']) 
			&& !(theGlobal->myKeys['d'] && !theGlobal->myKeys['D']))
		Dir.x = 0;
		Dir.y = 1;
		facingup = false;
		facingdown = true;

		SetAnimationCounter( GetAnimationCounter() + 1);
		if (GetAnimationCounter()> 3)
			SetAnimationCounter( 0 );

		//Do not allow movement when stopMovement is true
		//if (!stopMovement)
		//{
			//Check if Collision is detected
			if (!theGlobal->Collided(Pos+Vector3D(0,5,0), false, true, false, false, 
				theGlobal->theMap, theGlobal->theMap->mapOffset_x,theGlobal->theMap->mapOffset_y)
				&& !LR)
			{
				Pos.y = Pos.y + (int) (SPEED *  1.0f) ;
				bMoving = true;
				Walk(true);
			}
		//}
		}
	}

	//Check Collision of the hero before moving left
	Vector3D posL; //Fixes the Collision 
	posL.Set(Pos.x-7, Pos.y); //Buffer of 7

	//Move Left
	if ((theGlobal->myKeys['a'] || theGlobal->myKeys['A']))
	{
		if (!theGlobal->CheckEntrance(Pos,theGlobal->theMap,theGlobal->theMap->mapOffset_x,theGlobal->theMap->mapOffset_y))
		{
		//Alter Player Direction
		if (!(theGlobal->myKeys['w'] && !theGlobal->myKeys['W']) 
			&& !(theGlobal->myKeys['s'] && !theGlobal->myKeys['S']))
		Dir.y = 0;
		Dir.x = -1;
		SetAnimationInvert( true );
		weapon->SetAnimationInvert( true );
		facingup = false;
		facingdown = false;
		SetAnimationCounter( GetAnimationCounter() - 1);
		if (GetAnimationCounter()==0)
			SetAnimationCounter( 3 );

		//Do not allow movement when stopMovement is true
		//if (!CInputSystem::getInstance()->stopMovement)
		//{
			//Check if Collision is detected
			if (!theGlobal->Collided(posL, false, false, true, false, 
				theGlobal->theMap, theGlobal->theMap->mapOffset_x, theGlobal->theMap->mapOffset_y))
			{
				SetPos_x( GetPos().x - (int) (SPEED *  1.0f) );
				bMoving = true;
				Walk(true);
			}
		//}
		}
			//Check Collision of the hero before moving right

	}

			Vector3D posR; //Fixes the Collision 
		posR.Set(Pos.x+7, Pos.y); //Buffer of 7

	//Move Right
	if ((theGlobal->myKeys['d'] || theGlobal->myKeys['D']))
	{
		if (!theGlobal->CheckEntrance(Pos,theGlobal->theMap,theGlobal->theMap->mapOffset_x,theGlobal->theMap->mapOffset_y))
		{
		//Alter Player Direction
		if (!(theGlobal->myKeys['w'] && !theGlobal->myKeys['W']) 
			&& !(theGlobal->myKeys['s'] && !theGlobal->myKeys['S']))
		Dir.y = 0;
		Dir.x = 1;
		SetAnimationInvert( false );
		weapon->SetAnimationInvert(  false );
		facingup = false;
		facingdown = false;
		SetAnimationCounter( GetAnimationCounter() + 1);
		if (GetAnimationCounter()>3)
			SetAnimationCounter( 0 );

		//Do not allow movement when stopMovement is true
		//if (!stopMovement)
		//{
			//Check if Collision is detected
			if (!theGlobal->Collided(posR, false, false, false, true, 
				theGlobal->theMap, theGlobal->theMap->mapOffset_x, theGlobal->theMap->mapOffset_y))
			{
				SetPos_x( GetPos().x + (int) (SPEED *  1.0f) );
				bMoving = true;
				Walk(true);
			}
		//}
		}
	}

	if ((theGlobal->myKeys['e'] || theGlobal->myKeys['E']))
	{
		//Rot.x+=1;

		if (theGlobal->CheckDoor(Pos,Dir,theGlobal->theMap,theGlobal->theMap->mapOffset_x,theGlobal->theMap->mapOffset_y,myInventory->findItem("Lockpick")) == CMap::DOOR_LEFT_L)
		{
			notification = "Door is locked";
			notificationTimer = 50;
		}
		else 
		{
			int CHEST = theGlobal->CheckTreasure(Pos,Dir,theGlobal->theMap,theGlobal->theMap->mapOffset_x,theGlobal->theMap->mapOffset_y,myInventory->findItem("Lockpick"));
			if(CHEST == CMap::CHEST_LOCKED)
			{
				notification = "Chest is locked";
				notificationTimer = 50;
			}
			if(CHEST == CMap::CHEST_OPENED)
			{
				if (playerSound == NULL)//this type of code will only play once
				playerSound = theGlobal->SoundEngine->play2D("Sound/load.mp3", false, true);
				if (playerSound->getIsPaused() == true)
				playerSound ->setIsPaused(false);
				int random_loot = rand()%6+1;
				myInventory->addItem(random_loot);
				myInventory->addItem(7);
			}
			else
			{
				playerSound = NULL;
			}
		}
	}
	else if ((theGlobal->myKeys[13]))
	{
		weapon->Attack(Dir,Pos,true);
	}

	//Check if the player is standing still
	if (!theGlobal->myKeys['w'] && !theGlobal->myKeys['W'] &&
		!theGlobal->myKeys['a'] && !theGlobal->myKeys['A'] &&
		!theGlobal->myKeys['s'] && !theGlobal->myKeys['S'] &&
		!theGlobal->myKeys['d'] && !theGlobal->myKeys['D'])
		bMoving = false;

	//Toggle UD to False if player is not moving UD
	if (!theGlobal->myKeys['w'] && !theGlobal->myKeys['W'] &&
		!theGlobal->myKeys['s'] && !theGlobal->myKeys['S'])
		UD = false;

	//Toggle LR to False if player is not moving LR
	if (!theGlobal->myKeys['a'] && !theGlobal->myKeys['A'] &&
		!theGlobal->myKeys['d'] && !theGlobal->myKeys['D'])
		LR = false;

		//get item

	//for(unsigned i = 0; i < GetBulletListSize(); i++)
	//{
	//	for(unsigned a = 0; a < guardlist.size(); ++a)
	//	{
	//		CGuard *guard = guardlist[a];
	//		//can be lua-ed

	//		if ( (guard->GetPos() - GetBullet(i)->GetPos()).GetMagnitude2D() < 50)
	//		{
	//			myInventory->addItem(1);
	//			guard->active = false;
	//			guard->SetPos(Vector3D()); // reset back to zero
	//			break;
	//		}

	//	}
	//}
	for(unsigned a = 0; a < guardlist.size(); ++a)
	{
		CGuard *guard = guardlist[a];
		//can be lua-ed
		string guardweap = guard->weapon->checkProjectileCollision(Pos);
		if (guardweap != "NIL")
		{
			//myInventory->addItem(1);
			int DMG = weapon->GetDMG(guardweap);
			stringstream ss;
			ss << DMG;
			string sDMG = ss.str();
			float s = 1*(DMG/15);
			Vector3D c = Vector3D(1,1,1);
			if(((float)DMG/15) > 1)
			c = Vector3D(1,1,0);
			if(((float)DMG/15) > 1.5)
			c = Vector3D(1,0,0);
			DmgFont* tempDMG = new DmgFont(sDMG, Pos,s,c, 50);
			DmgList.push_back(tempDMG);
			if(Health.current < DMG)
				Health.current = 0;
			else 
				Health.current -= DMG;		//minus health according to players damage
			//guard->active = false;
			//guard->SetPos(Vector3D()); // reset back to zero
		}
		if (guard->getHealth().current <= 0)
		{
			if ((theGlobal->myKeys['e'] || theGlobal->myKeys['E']))
			{
				if((Pos- guard->GetPos()).GetMagnitude2D() < TILE_SIZE && !guard->loot)
				{
					guard->inventory = new Inventory();
					for(int i = 0; i < rand()%3 + 3; i++)
					{
						guard->inventory->addItem(rand()%9+1);
					}
					guard->inventory->addItem(7);
					guard->inventory->setAllItemsToBeOld();
					guard->loot = true;
				}
			}
			continue;
		}
		string weap = weapon->checkProjectileCollision(guard->GetPos());
		if (weap != "NIL")
		{
			int DMG = weapon->GetDMG(weap);
			stringstream ss;
			ss << DMG;
			string sDMG = ss.str();
			float s = 1*(DMG/15);
			Vector3D c = Vector3D(1,1,1);
			if(((float)DMG/15) > 1)
			c = Vector3D(1,1,0);
			if(((float)DMG/15) > 1.5)
			c = Vector3D(1,0,0);
			DmgFont* tempDMG = new DmgFont(sDMG, guard->GetPos(),s,c, 50);
			DmgList.push_back(tempDMG);
			guard->setCurrentHealth(guard->getHealth().current - DMG);		//minus health according to players damage
		}

	}
	for(unsigned a = 0; a < camlist.size(); ++a)
	{
		CSecurityCam *scam = camlist[a];//lol
		//can be lua-ed
		string scamweap = scam->weapon->checkProjectileCollision(Pos);
		if (scamweap != "NIL")
		{
			//myInventory->addItem(1);
			int DMG = weapon->GetDMG(scamweap);
			stringstream ss;
			ss << DMG;
			string sDMG = ss.str();
			float s = 0.7;
			Vector3D c = Vector3D(1,1,1);

			DmgFont* tempDMG = new DmgFont(sDMG, Pos,s,c, 50);
			DmgList.push_back(tempDMG);
			if(Health.current < DMG)
				Health.current = 0;
			else 
				Health.current -= DMG;		//minus health according to players damage
			//guard->active = false;
			//guard->SetPos(Vector3D()); // reset back to zero
		}
	}
	//Update Sprite
	if (!bMoving)
	{
		SetAnimationCounter(0);
	}

	//Set Player Direction
	//if (playerDir.GetMagnitude() != 0)
		//Dir = playerDir;
}

bool CPlayerInfo::Update(){
	keyboardUpdate();
	
	handleCurrEquipped();
	
	if(notificationTimer > 0)
	{
		notificationTimer--;
	}

	for(unsigned a = 0; a < DmgList.size(); ++a)
	{
		DmgList[a]->Timeleft--;
		DmgList[a]->Pos.y--;
		if(DmgList[a]->Timeleft <= 0)
			DmgList.erase(DmgList.begin() + a);
	}
	return true;
}
	
void CPlayerInfo::load()
{	
	ifstream read;
	int data[9];

	read.open ("SaveData.txt", fstream::in | fstream::app);
	for (int i = 0; i < 9; i++)
	{
		read >> data[i];
	}

	Pos.x = (float)data[0];
	Pos.y = (float)data[1];
}
void CPlayerInfo::save()
{
	ofstream outFile;

	outFile.open("SaveData.txt");

	outFile << Pos.x << endl 
		<< Pos.y << endl;
	cout << endl;

	outFile.close();
}

float CPlayerInfo::getHP(){
	return Health.current/Health.max*100;
}
void CPlayerInfo::setHP(float hp){
	Health.current = hp/100*Health.max;

	if (Health.current > Health.max)
		Health.current = Health.max;
	else if (Health.current < 0)
		Health.current = 0;
}

int CPlayerInfo::getMoney(){
	return Money;
}
void CPlayerInfo::setMoney(int m){
	Money = m;
}

string CPlayerInfo::getState()
{
	return state;
}

void CPlayerInfo::setState(string state)
{
	this->state = state;
}

//Inventory CPlayerInfo::getInventory(int slot)
//{
//	Inventory temp = Inventory(inventory[slot],inventAmt[slot]);
//
//	return temp;
//}

int CPlayerInfo::getInventory(int slot)
{
	return myInventory->getSlotItem(slot);;
}

//void CPlayerInfo::setInventory(Inventory set, int slot)
//{
//	inventory[slot] = set.inventory;
//	inventAmt[slot] = set.amount;
//}

bool CPlayerInfo::setInventory(int set, int slot)
{
	return myInventory->addItem(slot,set);
}

//Inventory* CPlayerInfo::getWInventory()
//{
//	Inventory temp[INVENTORY_SIZE];
//	for(unsigned i = 0; i < INVENTORY_SIZE; i++)
//	{
//		temp[i] = Inventory(inventory[i],inventAmt[i]);
//	}
//	return temp;
//}

int* CPlayerInfo::getWInventory()
{
	int temp[INVENTORY_SIZE];
	for(unsigned i = 0; i < INVENTORY_SIZE; i++)
	{
		temp[i] = myInventory->getSlotItem(i);
	}
	return temp;
}

//void CPlayerInfo::setWInventory(Inventory set[INVENTORY_SIZE])
//{
//	for(unsigned i = 0; i < INVENTORY_SIZE; i++)
//	{
//		inventory[i] = set[i].inventory;
//		inventAmt[i] = set[i].amount;
//	}
//}

bool CPlayerInfo::setWInventory(int set[INVENTORY_SIZE])
{
	for(unsigned i = 0; i < INVENTORY_SIZE; i++)
	{
		if(!myInventory->addItem(i,set[i]))
			return false;
	}
	return true;
}

string CPlayerInfo::getCurrEquipped()
{
	return weapon->getCurrEquipped();
}
void CPlayerInfo::setCurrEquipped(string weap)
{
	weapon->setCurrEquipped(weap);
}
void CPlayerInfo::setCurrEquippedFromInv(string weap)
{
	curr_inv_weap = weap;
}
void CPlayerInfo::handleCurrEquipped()
{
	if (weapon->getCurrAmmo() <= 0)
	{
		myInventory->removeItem(curr_inv_weap);
		curr_inv_weap = "NIL";
		setCurrEquipped(curr_inv_weap);
	}
	else if (myInventory->findItem(curr_inv_weap) == true)
	{
		myInventory->setNextSameItemToBeEquipped(curr_inv_weap);
		setCurrEquipped(curr_inv_weap);
	}
	else
	{
		curr_inv_weap = "NIL";
		setCurrEquipped(curr_inv_weap);
	}
}
int CPlayerInfo::getCurrAmmo()
{
	return weapon->getCurrAmmo();
}
void CPlayerInfo::setCurrAmmo(int ammo)
{
	weapon->setCurrAmmo(ammo);
}

Bullet* CPlayerInfo::GetBullet(int bullet)
{
	return weapon->GetBullet(bullet);
}

int CPlayerInfo::GetBulletListSize()
{
	return weapon->GetBulletListSize();
}
void CPlayerInfo::Walk(bool walk)
{
	if (!walk)
	{
		if (playerWalk == NULL)//this type of code is for looping codes
			playerWalk = theGlobal->SoundEngine->play2D("Sound/pl_dirt1.wav", false, true);
		if (playerWalk->getIsPaused() == true)
			playerWalk->setIsPaused(false);
		if (playerWalk->isFinished())//it will only play after it finished
			playerWalk = NULL;
	}
	else
	{
		if (playerWalk == NULL)//this type of code is for looping codes
			playerWalk = theGlobal->SoundEngine->play2D("Sound/pl_dirt1.wav", false, true);
		if (playerWalk->getIsPaused() == true)
			playerWalk->setIsPaused(false);
		if (playerWalk->isFinished())//it will only play after it finished
			playerWalk = NULL;
	}
}