#include "HUD.h"
#include "PlayState.h"
#include <time.h>

HUD::HUD(void)
	:	showHelp(false)
	,	showOptions(false)
	,	showInventory(false)
	,	volume_temp(70)
	,	LMouse_down_boolean(false)
	,	current_weapon(0)
	,   notEnoughMoney(false)
{
	for (unsigned i = 0; i < 61; i++)
		button1[i] = NULL;
	LoadTGA( &HUDtex[ 0 ], "Texture/HUD/white.tga");
	LoadTGA( &HUDtex[ 1 ], "Texture/HUD/optionsbutton.tga");
	LoadTGA( &HUDtex[ 2 ], "Texture/HUD/optionsbuttonMO.tga");
	LoadTGA( &HUDtex[ 3 ], "Texture/HUD/helpbutton.tga");
	LoadTGA( &HUDtex[ 4 ], "Texture/HUD/helpbuttonMO.tga");
	LoadTGA( &HUDtex[ 5 ], "Texture/HUD/minus.tga");
	LoadTGA( &HUDtex[ 6 ], "Texture/HUD/plus.tga");
	LoadTGA( &HUDtex[ 7 ], "Texture/HUD/unmutedbutton.tga");
	LoadTGA( &HUDtex[ 8 ], "Texture/HUD/mutedbutton.tga");
	LoadTGA( &HUDtex[ 9 ], "Texture/HUD/inventorybutton.tga");
	LoadTGA( &HUDtex[ 10 ], "Texture/HUD/inventorybuttonMO.tga");
	LoadTGA( &HUDtex[ 11 ], "Texture/HUD/help.tga");
	
	font_style = GLUT_BITMAP_HELVETICA_18;
	theGlobal = CGlobal::getInstance();
	weapManager = new CweaponManager();
	weapManager->Init();

	volume = CPlayState::Instance()->get_menu_volume();
	mutemusic = CPlayState::Instance()->get_menu_sounds_muted();
}

HUD::~HUD(void)
{
}

void HUD::printw (float x, float y, float z, char* format, ...)
{
	va_list args;	//  Variable argument list
	int len;		//	String length
	int i;			//  Iterator
	char * text;	//	Text

	//  Initialize a variable argument list
	va_start(args, format);

	//  Return the number of characters in the string referenced the list of arguments.
	//  _vscprintf doesn't count terminating '\0' (that's why +1)
	len = _vscprintf(format, args) + 1; 

	//  Allocate memory for a string of the specified size
	text = (char *)malloc(len * sizeof(char));

	//  Write formatted output using a pointer to the list of arguments
	vsprintf_s(text, len, format, args);

	//  End using variable argument list 
	va_end(args);

	//  Specify the raster position for pixel operations.
	glRasterPos3f (x, y, z);


	//  Draw the characters one by one
	for (i = 0; text[i] != '\0'; i++)
		glutBitmapCharacter(font_style, text[i]);

	//  Free the allocated memory for the string
	free(text);
}

void HUD::HelpScreen()
{
	// Help screen
	if (showHelp == true)
	{
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		glPushMatrix();
		glTranslatef(0, 62.5, 0);
		glScalef(25.6, 15.35, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[11].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		// Close help window button
		glColor4f(0.6f, 0.1f, 0.1f, 1.0f);
		glPushMatrix();
		glTranslatef(985, 77.5, 0);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,25);
				glTexCoord2f(1,0); glVertex2f(25,25);
				glTexCoord2f(1,1); glVertex2f(25,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		if(mouseX > 985 * w / 1024 && mouseX < 1010 * w / 1024 && mouseY > 70 * h / 745 && mouseY < 95 * h / 745)
		{
			glLoadIdentity();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(0.5f, 0.5f, 0.5f);
				printw (992, 97.5, 0, "X");
			glPopAttrib();

			// When clicked
			if (mouseState == false && mouseType == 0)
			{
				showHelp = false;
			}
		}
		else
		{
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1, 1, 1);
				printw (992, 97.5, 0, "X");
			glPopAttrib();
		}
	}
}

void HUD::OptionsScreen()
{
	if (showOptions == true)
	{
		// Options window
		glColor4f(0.2f, 0.2f, 0.2f, 0.95f);
		glPushMatrix();
		glTranslatef(360, 150, 0);
		glScalef(7.5/* * w / 1024*/, 12.25 * h / 745, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		// Lower volume button
		if (mouseX > 405 * w / 1024 && mouseX < 445 * w / 1024 && mouseY > 245 * h / 745 && mouseY < 285 * h / 745)
		{
			if (button1[1] == NULL)//this type of code will only play once
				button1[1] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
			if (button1[1]->getIsPaused() == true)
				button1[1]->setIsPaused(false);
			glColor4f(0.5f, 0.5f, 0.5f, 1.0f);
			glPushMatrix();
			glTranslatef(410, 260, 0);
			glEnable( GL_TEXTURE_2D );
			glEnable( GL_BLEND );
				glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				glBindTexture( GL_TEXTURE_2D, HUDtex[5].texID );
				glBegin(GL_QUADS);
					glTexCoord2f(0,1); glVertex2f(0,0);
					glTexCoord2f(0,0); glVertex2f(0,40);
					glTexCoord2f(1,0); glVertex2f(40,40);
					glTexCoord2f(1,1); glVertex2f(40,0);
				glEnd();
			glDisable( GL_BLEND );
			glDisable( GL_TEXTURE_2D );
			glPopMatrix();
			// When clicked
			if (mouseState == false && LMouse_down_boolean == false && mouseType == 0)
			{
				// DECREASE MUSIC VOLUME
				volume -= 5;
				
				if (volume < 0)
				{
					volume = 0;
				}

				LMouse_down_boolean = true;
			}
			else if (mouseState == true)
			{
				LMouse_down_boolean = false;
			}
		}
		else
		{
			glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
			glPushMatrix();
			glTranslatef(410, 260, 0);
			glEnable( GL_TEXTURE_2D );
			glEnable( GL_BLEND );
				glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				glBindTexture( GL_TEXTURE_2D, HUDtex[5].texID );
				glBegin(GL_QUADS);
					glTexCoord2f(0,1); glVertex2f(0,0);
					glTexCoord2f(0,0); glVertex2f(0,40);
					glTexCoord2f(1,0); glVertex2f(40,40);
					glTexCoord2f(1,1); glVertex2f(40,0);
				glEnd();
			glDisable( GL_BLEND );
			glDisable( GL_TEXTURE_2D );
			glPopMatrix();
			button1[1] = NULL;
		}

		// Increase volume button
		if(mouseX > 575 * w / 1024 && mouseX < 610 * w / 1024 && mouseY > 245 * h / 745 && mouseY < 285 * h / 745)
		{
			if (button1[2] == NULL)//this type of code will only play once
				button1[2] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
			if (button1[2]->getIsPaused() == true)
				button1[2]->setIsPaused(false);
			glColor4f(0.5f, 0.5f, 0.5f, 1.0f);
			glPushMatrix();
			glTranslatef(570, 260, 0);
			glEnable( GL_TEXTURE_2D );
			glEnable( GL_BLEND );
				glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				glBindTexture( GL_TEXTURE_2D, HUDtex[6].texID );
				glBegin(GL_QUADS);
					glTexCoord2f(0,1); glVertex2f(0,0);
					glTexCoord2f(0,0); glVertex2f(0,40);
					glTexCoord2f(1,0); glVertex2f(40,40);
					glTexCoord2f(1,1); glVertex2f(40,0);
				glEnd();
			glDisable( GL_BLEND );
			glDisable( GL_TEXTURE_2D );
			glPopMatrix();

			// When clicked
			if (mouseState == false && LMouse_down_boolean == false && mouseType == 0)
			{
				// INCREASE MUSIC VOLUME
				volume += 5;

				if (volume > 100)
				{
					volume = 100;
				}

				LMouse_down_boolean = true;
			}
			else if (mouseState == true)
			{
				LMouse_down_boolean = false;
			}
		}
		else
		{
			button1[2] = NULL;
			glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
			glPushMatrix();
			glTranslatef(570, 260, 0);
			glEnable( GL_TEXTURE_2D );
			glEnable( GL_BLEND );
				glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				glBindTexture( GL_TEXTURE_2D, HUDtex[6].texID );
				glBegin(GL_QUADS);
					glTexCoord2f(0,1); glVertex2f(0,0);
					glTexCoord2f(0,0); glVertex2f(0,40);
					glTexCoord2f(1,0); glVertex2f(40,40);
					glTexCoord2f(1,1); glVertex2f(40,0);
				glEnd();
			glDisable( GL_BLEND );
			glDisable( GL_TEXTURE_2D );
			glPopMatrix();
		}

		// Volume number (text)
		glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(0.0f, 0.0f, 0.0f);

			if (volume > 0)
				printw (500, 285.0, 0, "%.i", volume); // SHOW MUSIC VOLUME (WHEN MORE THAN 0)
			else
				printw (500, 285.0, 0, "0"); // SHOW MUSIC VOLUME (WHEN 0)
		
		glPopAttrib();

		// Mute/Unmute music button
		if (mutemusic == true)
		{
			if (mouseX > 490 * w / 1024 && mouseX < 530 * w / 1024 && mouseY > 360 * h / 745 && mouseY < 400 * h / 745)
			{
				if (button1[6] == NULL)//this type of code will only play once
					button1[6] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
				if (button1[6]->getIsPaused() == true)
					button1[6]->setIsPaused(false);
				glColor4f(0.5f, 0.5f, 0.5f, 1.0f);
				glPushMatrix();
				glTranslatef(490, 385, 0);
				glEnable( GL_TEXTURE_2D );
				glEnable( GL_BLEND );
					glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
					glBindTexture( GL_TEXTURE_2D, HUDtex[8].texID );
					glBegin(GL_QUADS);
						glTexCoord2f(0,1); glVertex2f(0,0);
						glTexCoord2f(0,0); glVertex2f(0,40);
						glTexCoord2f(1,0); glVertex2f(40,40);
						glTexCoord2f(1,1); glVertex2f(40,0);
					glEnd();
				glDisable( GL_BLEND );
				glDisable( GL_TEXTURE_2D );
				glPopMatrix();

				// When clicked
				if (mouseState == false && LMouse_down_boolean == false && mouseType == 0)
				{
					volume = volume_temp;
					mutemusic = false;
					LMouse_down_boolean = true;
				}
				else if (mouseState == true)
				{
					LMouse_down_boolean = false;
				}
			}
			else
			{
				button1[6] = NULL;
				glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
				glPushMatrix();
				glTranslatef(490, 385, 0);
				glEnable( GL_TEXTURE_2D );
				glEnable( GL_BLEND );
					glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
					glBindTexture( GL_TEXTURE_2D, HUDtex[8].texID );
					glBegin(GL_QUADS);
						glTexCoord2f(0,1); glVertex2f(0,0);
						glTexCoord2f(0,0); glVertex2f(0,40);
						glTexCoord2f(1,0); glVertex2f(40,40);
						glTexCoord2f(1,1); glVertex2f(40,0);
					glEnd();
				glDisable( GL_BLEND );
				glDisable( GL_TEXTURE_2D );
				glPopMatrix();
			}
		}
		else
		{
			if (mouseX > 490 * w / 1024 && mouseX < 530 * w / 1024 && mouseY > 360 * h / 745 && mouseY < 400 * h / 745)
			{
				glColor4f(0.5f, 0.5f, 0.5f, 1.0f);
				glPushMatrix();
				glTranslatef(490, 385, 0);
				glEnable( GL_TEXTURE_2D );
				glEnable( GL_BLEND );
					glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
					glBindTexture( GL_TEXTURE_2D, HUDtex[7].texID );
					glBegin(GL_QUADS);
						glTexCoord2f(0,1); glVertex2f(0,0);
						glTexCoord2f(0,0); glVertex2f(0,40);
						glTexCoord2f(1,0); glVertex2f(40,40);
						glTexCoord2f(1,1); glVertex2f(40,0);
					glEnd();
				glDisable( GL_BLEND );
				glDisable( GL_TEXTURE_2D );
				glPopMatrix();

				// When clicked
				if (mouseState == false && LMouse_down_boolean == false && mouseType == 0)
				{
					volume_temp = volume;
					volume = 0;
					mutemusic = true;
					LMouse_down_boolean = true;
				}
				else if (mouseState == true)
				{
					LMouse_down_boolean = false;
				}
			}
			else
			{
				glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
				glPushMatrix();
				glTranslatef(490, 385, 0);
				glEnable( GL_TEXTURE_2D );
				glEnable( GL_BLEND );
					glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
					glBindTexture( GL_TEXTURE_2D, HUDtex[7].texID );
					glBegin(GL_QUADS);
						glTexCoord2f(0,1); glVertex2f(0,0);
						glTexCoord2f(0,0); glVertex2f(0,40);
						glTexCoord2f(1,0); glVertex2f(40,40);
						glTexCoord2f(1,1); glVertex2f(40,0);
					glEnd();
				glDisable( GL_BLEND );
				glDisable( GL_TEXTURE_2D );
				glPopMatrix();
			}
		}

		// Resume Game button
		glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
		glPushMatrix();
		glTranslatef(401, 500, 0);
		glScalef(5.5/* * w / 1024*/, 1, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		if(mouseX > 400 * w / 1024 && mouseX < 620 * w / 1024 && mouseY > 465 * h / 745 && mouseY < 505 * h / 745)
		{
			if (button1[7] == NULL)//this type of code will only play once
				button1[7] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
			if (button1[7]->getIsPaused() == true)
				button1[7]->setIsPaused(false);
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(0.5f, 0.5f, 0.5f);
				printw (455, 527.5, 0, "Resume Game");
			glPopAttrib();

			// When clicked
			if (mouseState == false && mouseType == 0)
			{
				showOptions = false;
			}
		}
		else
		{
			button1[7] = NULL;
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1, 1, 1);
				printw (455, 527.5, 0, "Resume Game");
			glPopAttrib();
		}


		// Quit to Main Menu button
		glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
		glPushMatrix();
		glTranslatef(401, 560, 0);
		glScalef(5.5/* * w / 1024*/, 1, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		if(mouseX > 400 * w / 1024 && mouseX < 620 * w / 1024 && mouseY > 520 * h / 745 && mouseY < 560 * h / 745)
		{
			if (button1[8] == NULL)//this type of code will only play once
				button1[8] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
			if (button1[8]->getIsPaused() == true)
				button1[8]->setIsPaused(false);
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(0.5f, 0.5f, 0.5f);
				printw (435, 587.5, 0, "Quit to Main Menu");
			glPopAttrib();

			// When clicked
			if (mouseState == false && mouseType == 0)
			{
				// EXIT TO MAIN MENU
				CPlayState::Instance()->main_menu = true;
			}
		}
		else
		{
			button1[8] = NULL;
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1, 1, 1);
				printw (435, 587.5, 0, "Quit to Main Menu");
			glPopAttrib();
		}

		// Other text
		glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(0.0f, 0.0f, 0.0f);
			printw (437.5, 190.0, 0, "OPTIONS MENU");
		glPopAttrib();

		glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(0.0f, 0.0f, 0.0f);
			printw (455.0, 240.0, 0, "Music volume");
		glPopAttrib();

		glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(0.0f, 0.0f, 0.0f);
			printw (432.5, 360.0, 0, "Mute/Unmute music");
		glPopAttrib();
	}
}

void HUD::InventoryScreen()
{
	if (showInventory == true)
	{
		// Inventory window
		glColor4f(0.2f, 0.2f, 0.2f, 0.95f);
		glPushMatrix();
		glTranslatef(240, 200, 0);
		glScalef(9, 9.5, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(1, 1, 1);
			printw (375, 230, 0, "Inventory");
		glPopAttrib();


		// Close inventory window button
		glColor4f(0.6f, 0.1f, 0.1f, 1.0f);
		glPushMatrix();
		glTranslatef(565, 212, 0);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,25);
				glTexCoord2f(1,0); glVertex2f(25,25);
				glTexCoord2f(1,1); glVertex2f(25,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		if(mouseX > 565 * w / 1024 && mouseX < 590 * w / 1024 && mouseY > 202 * h / 745 && mouseY < 227 * h / 745)
		{
			if (button1[54] == NULL)//this type of code will only play once
				button1[54] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
			if (button1[54]->getIsPaused() == true)
				button1[54]->setIsPaused(false);
			glLoadIdentity();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(0.5f, 0.5f, 0.5f);
				printw (572, 231, 0, "X");
			glPopAttrib();

			// When clicked
			if (mouseState == false && mouseType == 0)
			{
				showInventory = false;
				CPlayState::Instance()->thePlayer->myInventory->resetCraftingSlots();
				CPlayState::Instance()->thePlayer->myInventory->setAllItemsToBeOld();
				CPlayState::Instance()->thePlayer->myInventory->resetAllItemsSelectedForCrafting();
			}
		}
		else
		{
			button1[54] = NULL;
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1, 1, 1);
				printw (572, 231, 0, "X");
			glPopAttrib();
		}


		CraftingScreen();


		// Inventory slots
		int slot_itr = 0;

		for (int i = 0; i < 4; ++i)
		{
			for (int j = 0; j < 5; ++j)
			{
				// Render yellow-highlight for inventory slot (slot item equipped)
				if (CPlayState::Instance()->thePlayer->myInventory->getSlotItemEquippedStatus(slot_itr) == true)
				{
					glColor4f(1.0f, 1.0f, 0.0f, 0.75f);
					glPushMatrix();
					glTranslatef(265 + (65 * j), 255 + (65 * i), 0);
					glEnable(GL_TEXTURE_2D);
					glEnable(GL_BLEND);
					glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
					glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
						glBegin(GL_QUADS);
						glTexCoord2f(0, 1); glVertex2f(0, 0);
						glTexCoord2f(0, 0); glVertex2f(0, 50);
						glTexCoord2f(1, 0); glVertex2f(50, 50);
						glTexCoord2f(1, 1); glVertex2f(50, 0);
						glEnd();
					glDisable(GL_BLEND);
					glDisable(GL_TEXTURE_2D);
					glPopMatrix();
				}
				// Render red-highlight for inventory slot (slot item selected for crafting)
				if (CPlayState::Instance()->thePlayer->myInventory->getSlotItemSelectedForCraftingStatus(slot_itr) == true)
				{
					glColor4f(1.0f, 0.0f, 0.0f, 0.75f);
					glPushMatrix();
					glTranslatef(265 + (65 * j), 255 + (65 * i), 0);
					glEnable(GL_TEXTURE_2D);
					glEnable(GL_BLEND);
					glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
					glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
						glBegin(GL_QUADS);
						glTexCoord2f(0, 1); glVertex2f(0, 0);
						glTexCoord2f(0, 0); glVertex2f(0, 50);
						glTexCoord2f(1, 0); glVertex2f(50, 50);
						glTexCoord2f(1, 1); glVertex2f(50, 0);
						glEnd();
					glDisable(GL_BLEND);
					glDisable(GL_TEXTURE_2D);
					glPopMatrix();
				}
				glColor4f(0.35f, 0.35f, 0.35f, 0.4525f);
				glPushMatrix();
				glTranslatef(265 + (65 * j), 255 + (65 * i), 0);
				glEnable( GL_TEXTURE_2D );
				glEnable( GL_BLEND );
					glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
					glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
					glBegin(GL_QUADS);
						glTexCoord2f(0,1); glVertex2f(0,0);
						glTexCoord2f(0,0); glVertex2f(0,50);
						glTexCoord2f(1,0); glVertex2f(50,50);
						glTexCoord2f(1,1); glVertex2f(50,0);
					glEnd();
				glDisable( GL_BLEND );
				glDisable( GL_TEXTURE_2D );
				//glPopMatrix();

				HUDInventory->renderInventorySlot(slot_itr);

				
				// Mouse over inventory item slot
				if ((mouseX > (265 + (65 * j)) * w / 1024) && (mouseX < (315 + (65 * j)) * w / 1024) && (mouseY >(235 + (60 * i)) * h / 745) && (mouseY < (285 + (60 * i)) * h / 745))
				{

					float mouseX_new = (float)mouseX * (1024 / (float)w);
					float mouseY_new = (float)mouseY * (745 / (float)h);

					std::string item_name, item_description, item_description2;
					item_name = HUDInventory->getSlotItemName(slot_itr);
					if (item_name != "")
					{

						if (button1[10 + i + (4)*(j)] == NULL)//this type of code will only play once
							button1[10 + i + (4)*(j)] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
						if (button1[10 + i + (4)*(j)]->getIsPaused() == true)
							button1[10 + i + (4)*(j)]->setIsPaused(false);
					}
					item_description = HUDInventory->getSlotItemDescription(slot_itr);
					item_description2 = HUDInventory->getSlotItemDescription2(slot_itr);
					int text_box_width = item_name.size();

					glColor4f(0.025f, 0.025f, 0.025f, 1);
					glPushMatrix();
					glTranslatef(mouseX_new - 40, mouseY_new - 25, 0);
					glEnable( GL_TEXTURE_2D );
					glEnable( GL_BLEND );
						glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
						glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
						glBegin(GL_QUADS);
							glTexCoord2f(0,1); glVertex2f(0,0);
							glTexCoord2f(0,0); glVertex2f(0,28);
							glTexCoord2f(1,0); glVertex2f(11 * text_box_width,28);
							glTexCoord2f(1,1); glVertex2f(11 * text_box_width,0);
						glEnd();
					glDisable( GL_BLEND );
					glDisable( GL_TEXTURE_2D );
					glPopMatrix();

					// Item name
					glLoadIdentity();
					glPushAttrib(GL_ALL_ATTRIB_BITS);
						glColor3f(1, 1, 1);
						printw(mouseX_new - 36, mouseY_new - 5, 0, "%s", item_name.c_str());
					glPopAttrib();

					// Item description
					glLoadIdentity();
					glPushAttrib(GL_ALL_ATTRIB_BITS);
						glColor3f(1, 1, 1);
						printw(265, 532.5, 0, "%s", item_description.c_str());
					glPopAttrib();

					// Item description2
					glLoadIdentity();
					glPushAttrib(GL_ALL_ATTRIB_BITS);
						glColor3f(1, 1, 1);
						printw(265, 557.5, 0, "%s", item_description2.c_str());
					glPopAttrib();
					

					// When clicked (Left mouse button - USE ITEM)
					if (mouseState == false && LMouse_down_boolean == false && mouseType == 0)
					{
						confirm_temp_item_id = slot_itr;
						confirm_temp_item_name = item_name;
						showConfirmUseScreen = true;

						LMouse_down_boolean = true;
					}
					// When clicked (Right mouse button - CRAFT WITH ITEM)
					else if (mouseState == false && LMouse_down_boolean == false && mouseType == 1)
					{
						CPlayState::Instance()->thePlayer->myInventory->craftWithSlotItem(slot_itr);

						LMouse_down_boolean = true;
					}
					// When clicked (Middle mouse button - DISCARD ITEM)
					else if (mouseState == false && LMouse_down_boolean == false && mouseType == 2)
					{
						confirm_temp_item_id = slot_itr;
						confirm_temp_item_name = item_name;
						showConfirmDiscardScreen = true;

						CPlayState::Instance()->thePlayer->myInventory->resetCraftingSlots();

						LMouse_down_boolean = true;
					}
					else if (mouseState == true)
					{
						LMouse_down_boolean = false;
					}

				}
				else
				{
					
					button1[10 + i + (4)*(j)] = NULL;
						
				}
				slot_itr++;
			}
		}
	}
}


bool HUD::InventoryScreen(Inventory *inventory, bool steal, bool mState,int mType)
{
	glPushMatrix;
	// Inventory window
	glColor4f(0.2f, 0.2f, 0.2f, 0.95f);
		glPushMatrix();
		glTranslatef(240, 200, 0);
		glScalef(9, 9.5, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

	glLoadIdentity ();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glColor3f(1, 1, 1);
	if(!steal)
	printw (335, 230, 0, "The Black Market");
	else
	printw (375, 230, 0, "Stash");
	glPopAttrib();


	// Close inventory window button
	glColor4f(0.6f, 0.1f, 0.1f, 1.0f);
	glPushMatrix();
	glTranslatef(565, 212, 0);
	glEnable( GL_TEXTURE_2D );
	glEnable( GL_BLEND );
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
	glBegin(GL_QUADS);
	glTexCoord2f(0,1); glVertex2f(0,0);
	glTexCoord2f(0,0); glVertex2f(0,25);
	glTexCoord2f(1,0); glVertex2f(25,25);
	glTexCoord2f(1,1); glVertex2f(25,0);
	glEnd();
	glDisable( GL_BLEND );
	glDisable( GL_TEXTURE_2D );
	glPopMatrix();

	if(mouseX > 565 * w / 1024 && mouseX < 590 * w / 1024 && mouseY > 202 * h / 745 && mouseY < 227 * h / 745)
	{
		if (button1[50] == NULL)//this type of code will only play once
			button1[50] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
		if (button1[50]->getIsPaused() == true)
			button1[50]->setIsPaused(false);
		glPopMatrix;
		glLoadIdentity();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
		glColor3f(0.5f, 0.5f, 0.5f);
		printw (572, 231, 0, "X");
		glPopAttrib();
		
		if (mState == false && mType == 0)
			return false;
	}
	else
	{
		button1[50] = NULL;
		glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
		glColor3f(1, 1, 1);
		printw (572, 231, 0, "X");
		glPopAttrib();
	}

	// Inventory slots
	int slot_itr = 0;

	for (int i = 0; i < 4; ++i)
	{
		for (int j = 0; j < 5; ++j)
		{
			glColor4f(0.35f, 0.35f, 0.35f, 0.4525f);
			glPushMatrix();
			glTranslatef(265 + (65 * j), 255 + (65 * i), 0);
			glEnable( GL_TEXTURE_2D );
			glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
			glTexCoord2f(0,1); glVertex2f(0,0);
			glTexCoord2f(0,0); glVertex2f(0,50);
			glTexCoord2f(1,0); glVertex2f(50,50);
			glTexCoord2f(1,1); glVertex2f(50,0);
			glEnd();
			glDisable( GL_BLEND );
			glDisable( GL_TEXTURE_2D );
			//glPopMatrix();

			inventory->renderInventorySlot(slot_itr);

			// Mouse over inventory item slot
			if ( !showConfirmBuyScreen && (mouseX > (265 + (65 * j)) * w / 1024) && (mouseX < (315 + (65 * j)) * w / 1024) && (mouseY > (235 + (60 * i)) * h / 745) && (mouseY < (285 + (60 * i)) * h / 745))
			{

				float mouseX_new = (float) mouseX * (1024 / (float) w);
				float mouseY_new = (float) mouseY * (745 / (float) h);

				std::string item_name, item_description, item_description2;
				item_name = inventory->getSlotItemName(slot_itr);
				item_description = inventory->getSlotItemDescription(slot_itr);
				item_description2 = inventory->getSlotItemDescription2(slot_itr);
				int text_box_width = item_name.size();
				if (item_name != "")
				{
					if (button1[30 + i + (4)*(j)] == NULL)//this type of code will only play once
						button1[30 + i + (4)*(j)] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
					if (button1[30 + i + (4)*(j)]->getIsPaused() == true)
						button1[30 + i + (4)*(j)]->setIsPaused(false);
				}

				glColor4f(0.025f, 0.025f, 0.025f, 1);
				glPushMatrix();
				glTranslatef(mouseX_new - 40, mouseY_new - 25, 0);
				glEnable( GL_TEXTURE_2D );
				glEnable( GL_BLEND );
				glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
				glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,28);
				glTexCoord2f(1,0); glVertex2f(11 * text_box_width,28);
				glTexCoord2f(1,1); glVertex2f(11 * text_box_width,0);
				glEnd();
				glDisable( GL_BLEND );
				glDisable( GL_TEXTURE_2D );
				glPopMatrix();

				// Item name
				glLoadIdentity();
				glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1, 1, 1);
				printw(mouseX_new - 36, mouseY_new - 5, 0, "%s", item_name.c_str());
				glPopAttrib();

			
				// Item description
				glLoadIdentity();
				glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1, 1, 1);
				printw(265, 532.5, 0, "%s", item_description.c_str());
				glPopAttrib();

				// Item description2
				glLoadIdentity();
				glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1, 1, 1);
				printw(265, 557.5, 0, "%s", item_description2.c_str());
				glPopAttrib();



				// When clicked (Left mouse button - USE ITEM)
				if (mState == false && mType == 0)
				{
					confirm_temp_item_id = slot_itr;
					confirm_temp_item_name = item_name;
					showConfirmBuyScreen = true;

					LMouse_down_boolean = true;
				}


				else if (mState == true)
				{
					LMouse_down_boolean = false;
				}
			}
			else
			{
				button1[30 + i + (4)*(j) ]= NULL;
			}
			slot_itr++;
		}
	}
	ConfirmBuyScreen(inventory,confirm_temp_item_name, confirm_temp_item_id,steal, mState,mType);
	return true;
}

void HUD::ConfirmBuyScreen(Inventory *inventory,std::string item_name, int slot_num, bool steal, bool mState,int mType)
{
	if (showConfirmBuyScreen == true && inventory->getSlotItem(slot_num) != 0)// && CPlayState::Instance()->thePlayer->getMoney() < 0)
	{
		// Use confirmation window
		glColor4f(0.2f, 0.2f, 0.2f, 0.95f);
		glPushMatrix();
		glTranslatef(350, 250, 0);
		glScalef(8, 4.7, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
				glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(1.0f, 1.0f, 1.0f);
			if(steal)
			printw (455 - (5 * item_name.length()), 320, 0, "Loot '%s' ?", item_name.c_str());
			else if(notEnoughMoney)
			{
				printw (455 - (5 * item_name.length()), 320, 0, "Not enough money!", item_name.c_str(), inventory->getSlotPrice(slot_num));
			}
			else
			printw (455 - (5 * item_name.length()), 320, 0, "Buy item '%s' for $%d?", item_name.c_str(), inventory->getSlotPrice(slot_num));
		glPopAttrib();
		// 'Yes' button
		if(!notEnoughMoney)
		{
			glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
			glPushMatrix();
			glTranslatef(415, 380, 0);
			glScalef(1.5, 1, 1);
			glEnable( GL_TEXTURE_2D );
			glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
			glTexCoord2f(0,1); glVertex2f(0,0);
			glTexCoord2f(0,0); glVertex2f(0,40);
			glTexCoord2f(1,0); glVertex2f(40,40);
			glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
			glDisable( GL_BLEND );
			glDisable( GL_TEXTURE_2D );
			glPopMatrix();
			if(mouseX > 415 * w / 1024 && mouseX < 475 * w / 1024 && mouseY > 355 * h / 745 && mouseY < 390 * h / 745)
			{
				if (button1[52] == NULL)//this type of code will only play once
					button1[52] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
				if (button1[52]->getIsPaused() == true)
					button1[52]->setIsPaused(false);
				glLoadIdentity ();
				glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(0.2f, 0.2f, 0.2f);
				printw (427.5, 407.5, 0, "Yes");
				glPopAttrib();
				// When clicked
			
				if (mouseState == false && mouseType == 0 && LMouse_down_boolean == false)
				{
					if(!steal)
					{
						if(CPlayState::Instance()->thePlayer->getMoney() >= inventory->getSlotPrice(slot_num))
						{
							CPlayState::Instance()->thePlayer->setMoney(CPlayState::Instance()->thePlayer->getMoney()-inventory->getSlotPrice(slot_num));
							CPlayState::Instance()->thePlayer->myInventory->addItem(inventory->getSlotItem(slot_num));
							inventory->emptySlot(slot_num);
							showConfirmBuyScreen = false;
						}
						else
						{
							notEnoughMoney = true;
						}
					}
					else
					{
						CPlayState::Instance()->thePlayer->myInventory->addItem(inventory->getSlotItem(slot_num));
						inventory->emptySlot(slot_num);
						showConfirmBuyScreen = false;
					}
					LMouse_down_boolean = true;
				}
				else
					LMouse_down_boolean = false;
			}
			else 
			{
				button1[52] = NULL;
				glLoadIdentity ();
				glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1.0f, 1.0f, 1.0f);
				printw (427.5, 407.5, 0, "Yes");
				glPopAttrib();
			}


			// 'No' button
			glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
			glPushMatrix();
			glTranslatef(545, 380, 0);
			glScalef(1.5, 1, 1);
			glEnable( GL_TEXTURE_2D );
			glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
			glTexCoord2f(0,1); glVertex2f(0,0);
			glTexCoord2f(0,0); glVertex2f(0,40);
			glTexCoord2f(1,0); glVertex2f(40,40);
			glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
			glDisable( GL_BLEND );
			glDisable( GL_TEXTURE_2D );
			glPopMatrix();

			if(mouseX > 545 * w / 1024 && mouseX < 605 * w / 1024 && mouseY > 355 * h / 745 && mouseY < 390 * h / 745)
			{
				if (button1[53] == NULL)//this type of code will only play once
					button1[53] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
				if (button1[53]->getIsPaused() == true)
					button1[53]->setIsPaused(false);
				glLoadIdentity ();
				glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(0.2f, 0.2f, 0.2f);
				printw (562.5, 407.5, 0, "No");
				glPopAttrib();

				// When clicked
				if (mState == false && mType == 0)
				{
					showConfirmBuyScreen = false;
				}
			}
			else
			{
				button1[53] = NULL;
				glLoadIdentity ();
				glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1.0f, 1.0f, 1.0f);
				printw (562.5, 407.5, 0, "No");
				glPopAttrib();
			}
		}
		if(notEnoughMoney) 
		{
			glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
			glPushMatrix();
			glTranslatef(480, 380, 0);
			glScalef(1.5, 1, 1);
			glEnable( GL_TEXTURE_2D );
			glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
			glTexCoord2f(0,1); glVertex2f(0,0);
			glTexCoord2f(0,0); glVertex2f(0,40);
			glTexCoord2f(1,0); glVertex2f(40,40);
			glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
			glDisable( GL_BLEND );
			glDisable( GL_TEXTURE_2D );
			glPopMatrix();
			if(mouseX > 480 * w / 1024 && mouseX < 540 * w / 1024 && mouseY > 355 * h / 745 && mouseY < 390 * h / 745)
			{
				glLoadIdentity ();
				glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(0.2f, 0.2f, 0.2f);
				printw (488.5, 407.5, 0, "Ok");
				glPopAttrib();
				if (mState == false && mType == 0)
				{
					{
						notEnoughMoney = false;
						showConfirmBuyScreen = false;
					}
				}
			}
			else
			{
				
				glLoadIdentity ();
				glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1.0f, 1.0f, 1.0f);
				printw (488.5, 407.5, 0, "Ok");
				glPopAttrib();
			}
		}
	}
	else
		showConfirmBuyScreen = false;
}

void HUD::ConfirmUseScreen(std::string item_name, int slot_num)
{
	if (showConfirmUseScreen == true && CPlayState::Instance()->thePlayer->myInventory->getSlotItemUseableStatus(slot_num) == true)
	{
		showInventory = false;

		// Use confirmation window
		glColor4f(0.2f, 0.2f, 0.2f, 0.95f);
		glPushMatrix();
		glTranslatef(350, 250, 0);
		glScalef(8, 4.7, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
				glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();


		// 'Yes' button
		glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
		glPushMatrix();
		glTranslatef(415, 380, 0);
		glScalef(1.5, 1, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(1.0f, 1.0f, 1.0f);
			printw (455 - (5 * item_name.length()), 320, 0, "Use item '%s'?", item_name.c_str());
		glPopAttrib();

		if(mouseX > 415 * w / 1024 && mouseX < 475 * w / 1024 && mouseY > 355 * h / 745 && mouseY < 390 * h / 745)
		{
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(0.2f, 0.2f, 0.2f);
				printw (427.5, 407.5, 0, "Yes");
			glPopAttrib();

			// When clicked
			if (mouseState == false && mouseType == 0 && LMouse_down_boolean == false)
			{
				showConfirmUseScreen = false;
				showInventory = true;
 
				CPlayState::Instance()->thePlayer->myInventory->useSlotItem(slot_num);
			
				LMouse_down_boolean = true;
			}
			else
				LMouse_down_boolean = false;
		}
		else
		{
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1.0f, 1.0f, 1.0f);
				printw (427.5, 407.5, 0, "Yes");
			glPopAttrib();
		}


		// 'No' button
		glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
		glPushMatrix();
		glTranslatef(545, 380, 0);
		glScalef(1.5, 1, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		if(mouseX > 545 * w / 1024 && mouseX < 605 * w / 1024 && mouseY > 355 * h / 745 && mouseY < 390 * h / 745)
		{
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(0.2f, 0.2f, 0.2f);
				printw (562.5, 407.5, 0, "No");
			glPopAttrib();

			// When clicked
			if (mouseState == false && mouseType == 0 && LMouse_down_boolean == false)
			{
				showConfirmUseScreen = false;
				showInventory = true;

				LMouse_down_boolean = true;
			}
			else
				LMouse_down_boolean = false;
		}
		else
		{
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1.0f, 1.0f, 1.0f);
				printw (562.5, 407.5, 0, "No");
			glPopAttrib();
		}
	}
	else
		showConfirmUseScreen = false;
}

void HUD::ConfirmDiscardScreen(string item_name, int slot_num)
{
	if (showConfirmDiscardScreen == true && CPlayState::Instance()->thePlayer->myInventory->getSlotItemDiscardableStatus(slot_num) == true)
	{
		showInventory = false;

		// Use confirmation window
		glColor4f(0.2f, 0.2f, 0.2f, 0.95f);
		glPushMatrix();
		glTranslatef(350, 250, 0);
		glScalef(8, 4.7, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
				glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();


		// 'Yes' button
		glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
		glPushMatrix();
		glTranslatef(415, 380, 0);
		glScalef(1.5, 1, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(1.0f, 1.0f, 1.0f);
			printw (455 - (5 * item_name.length()), 320, 0, "Discard item '%s'?", item_name.c_str());
		glPopAttrib();

		if(mouseX > 415 * w / 1024 && mouseX < 475 * w / 1024 && mouseY > 355 * h / 745 && mouseY < 390 * h / 745)
		{
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(0.2f, 0.2f, 0.2f);
				printw (427.5, 407.5, 0, "Yes");
			glPopAttrib();

			// When clicked
			if (mouseState == false && mouseType == 0 && LMouse_down_boolean == false)
			{
				showConfirmDiscardScreen = false;
				showInventory = true;

				CPlayState::Instance()->thePlayer->myInventory->emptySlot(slot_num);

				LMouse_down_boolean = true;
			}
			else
				LMouse_down_boolean = false;
		}
		else
		{
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1.0f, 1.0f, 1.0f);
				printw (427.5, 407.5, 0, "Yes");
			glPopAttrib();
		}


		// 'No' button
		glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
		glPushMatrix();
		glTranslatef(545, 380, 0);
		glScalef(1.5, 1, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		if(mouseX > 545 * w / 1024 && mouseX < 605 * w / 1024 && mouseY > 355 * h / 745 && mouseY < 390 * h / 745)
		{
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(0.2f, 0.2f, 0.2f);
				printw (562.5, 407.5, 0, "No");
			glPopAttrib();

			// When clicked
			if (mouseState == false && mouseType == 0 && LMouse_down_boolean == false)
			{
				showConfirmDiscardScreen = false;
				showInventory = true;

				LMouse_down_boolean = true;
			}
			else
				LMouse_down_boolean = false;
		}
		else
		{
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1.0f, 1.0f, 1.0f);
				printw (562.5, 407.5, 0, "No");
			glPopAttrib();
		}
	}
	else
		showConfirmDiscardScreen = false;
}

void HUD::CraftingScreen()
{
	// Crafting window
		glColor4f(0.2f, 0.2f, 0.2f, 0.95f);
		glPushMatrix();
		glTranslatef(610, 200, 0);
		glScalef(9, 4.7, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(1, 1, 1);
			printw (755, 230, 0, "Crafting");
		glPopAttrib();


		// 1st crafting spot
		glColor4f(0.35f, 0.35f, 0.35f, 0.4525f);
		glPushMatrix();
		glTranslatef(650, 255, 0);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,50);
				glTexCoord2f(1,0); glVertex2f(50,50);
				glTexCoord2f(1,1); glVertex2f(50,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(1, 1, 1);
			printw (727.5, 285, 0, "+");
		glPopAttrib();

		// 2nd crafting spot
		glColor4f(0.35f, 0.35f, 0.35f, 0.4525f);
		glPushMatrix();
		glTranslatef(765, 255, 0);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,50);
				glTexCoord2f(1,0); glVertex2f(50,50);
				glTexCoord2f(1,1); glVertex2f(50,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(1, 1, 1);
			printw (842.5, 285, 0, "=");
		glPopAttrib();

		// Product spot
		glColor4f(0.35f, 0.35f, 0.35f, 0.4525f);
		glPushMatrix();
		glTranslatef(880, 255, 0);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,50);
				glTexCoord2f(1,0); glVertex2f(50,50);
				glTexCoord2f(1,1); glVertex2f(50,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		// Craft item button
		glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
		glPushMatrix();
		glTranslatef(680, 330, 0);
		glScalef(5.5, 1, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		if(mouseX > 680 * w / 1024 && mouseX < 900 * w / 1024 && mouseY > 305 * h / 745 && mouseY < 345 * h / 745)
		{
			if (button1[55] == NULL)//this type of code will only play once
				button1[55] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
			if (button1[55]->getIsPaused() == true)
				button1[55]->setIsPaused(false);
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(0.5f, 0.5f, 0.5f);
				printw (750, 355.5, 0, "Craft item");
			glPopAttrib();

			// When clicked
			if (mouseState == false && mouseType == 0)
			{
				// Attempt to craft product item
				if (CPlayState::Instance()->thePlayer->myInventory->attemptCrafting())
				{
					//if (button1[56] == NULL)//this type of code will only play once
					//	button1[56] = 
					theGlobal->SoundEngine->play2D("Sound/load.wav", false, true);
					/*if (button1[56]->getIsPaused() == true)
						button1[56]->setIsPaused(false);*/
				}
			}
		}
		else
		{
			button1[55] = NULL;
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1, 1, 1);
				printw (750, 355.5, 0, "Craft item");
			glPopAttrib();
		}
		// Reset crafting slots when crafting slot 1 or 2 are selected
		if((mouseX > 650 * w / 1024 && mouseX < 700 * w / 1024 && mouseY > 235 * h / 745 && mouseY < 285 * h / 745) || (mouseX > 765 * w / 1024 && mouseX < 815 * w / 1024 && mouseY > 235 * h / 745 && mouseY < 285 * h / 745))
		{
			if (button1[56] == NULL)//this type of code will only play once
				button1[56] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
			if (button1[56]->getIsPaused() == true)
				button1[56]->setIsPaused(false);
			float mouseX_new = (float) mouseX * (1024 / (float) w);
			float mouseY_new = (float) mouseY * (745 / (float) h);

			// 'Reset crafting slots' text
			glLoadIdentity ();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1.0f, 1.0f, 0.0f);
				printw (mouseX_new - 10, mouseY_new + 60, 0, "Reset crafting slots");
			glPopAttrib();

			// When clicked
			if (mouseState == false && (mouseType == 0 || mouseType == 1 || mouseType == 2))
			{	
				CPlayState::Instance()->thePlayer->myInventory->resetCraftingSlots();
			}
		}
		else
		{
			button1[56] = NULL;
		}
		HUDInventory->renderCraftingSlots();
}

void HUD::drawHealthMeter(void)
{
	glLoadIdentity ();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
		glColor3f(0.0f, 0.0f, 0.0f);
		printw (110.0, 700.0, 0, "Health -");
	glPopAttrib();

	if (health >= 70)
	{
		glColor4f(0.0f, 1.0f, 0.0f, 1.0f);

		glPushAttrib(GL_ALL_ATTRIB_BITS);
			printw (185, 700.0, 0, "Good Condition");
		glPopAttrib();
	}
	else if (health >= 30 && health < 70)
	{
		glColor4f(1.0f, 1.0f, 0.0f, 1.0f);

		glPushAttrib(GL_ALL_ATTRIB_BITS);
			printw (185, 700.0, 0, "Injured");
		glPopAttrib();
	}
	else
	{
		glColor4f(1.0f, 0.0f, 0.0f, 1.0f);

		glPushAttrib(GL_ALL_ATTRIB_BITS);
			printw (185, 700.0, 0, "Dying");
		glPopAttrib();
	}

	glPushMatrix();
	glTranslatef(95, 705, 0);
	glEnable( GL_TEXTURE_2D );
	glEnable( GL_BLEND );
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
		glBegin(GL_QUADS);
			glTexCoord2f(0,1); glVertex2f(0,5);
			glTexCoord2f(0,0); glVertex2f(0,25);
			glTexCoord2f(1,0); glVertex2f(health*2.25,25);
			glTexCoord2f(1,1); glVertex2f(health*2.25,5);
		glEnd();
	glDisable( GL_BLEND );
	glDisable( GL_TEXTURE_2D );
	glPopMatrix();

	glPushAttrib(GL_ALL_ATTRIB_BITS);
		printw (((health*2.25) + 100), 726.5, 0, "%i", health);
	glPopAttrib();

	
}

void HUD::drawDetectionStatus(void)
{
	glLoadIdentity ();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
		glColor3f(0.0f, 0.0f, 0.0f);
		printw (125.0, 760.0, 0, "Detection Status:");
	glPopAttrib();

	// Undetected
	if (detection_state == 0)
	{
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(0.0f, 1.0f, 0.0f);
			printw (145.0, 785.0, 0, "Undetected");
		glPopAttrib();
	}
	// Detected
	else
	{
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(1.0f, 0.0f, 0.0f);
			printw (145.0, 785.0, 0, "Detected");
		glPopAttrib();
		detection_state = 0;
	}
}

void HUD::renderLevel(void)
{
	glLoadIdentity ();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
		glColor3f(0.0f, 0.0f, 0.0f);
		printw (475, 40, 0, "Level %.i", level);
	glPopAttrib();
}

void HUD::renderCurrentWeapon(void)
{
	// Display literal "Current weapon" text
	glLoadIdentity ();
	glPushAttrib(GL_ALL_ATTRIB_BITS);
		glColor3f(0.0f, 0.0f, 0.0f);
		printw (432.5, 700.0, 0, "Current weapon");
	glPopAttrib();

	if(currEquipped != "NIL")
	{
		glPushMatrix();
		glTranslatef(455, 710, 0);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glBindTexture( GL_TEXTURE_2D, weapManager->getWeapTex(currEquipped).texID );
		glBegin(GL_QUADS);
		glTexCoord2f(0,1); glVertex2f(0,0);
		glTexCoord2f(0,0); glVertex2f(0,85);
		glTexCoord2f(1,0); glVertex2f(85,85);
		glTexCoord2f(1,1); glVertex2f(85,0);
		glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();
	}
}

void HUD::renderHelpButton()
{
	// When mouse over
	if(mouseX > (850 * w / 1024) && mouseX < (900 * w / 1024) && mouseY > (5 * h / 745) && mouseY < (55 * h / 745) && showInventory != true && showConfirmUseScreen != true)
	{
		if (button1[3] == NULL)//this type of code will only play once
			button1[3] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
		if (button1[3]->getIsPaused() == true)
			button1[3]->setIsPaused(false);
		glPushMatrix();
		glTranslatef(850, 5, 0);
		glScalef(1.3, 1.3 * h / 745, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[4].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		float mouseX_new = (float) mouseX * (1024 / (float) w);
		float mouseY_new = (float) mouseY * (745 / (float) h);

		if (showHelp == false)
		{
			glLoadIdentity();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1, 1, 0);
				printw(mouseX_new, mouseY_new + 45, 0, "Help");
			glPopAttrib();
		}
		else
		{
			glLoadIdentity();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1, 1, 0);
				printw(mouseX_new, mouseY_new + 45, 0, "Close Help");
			glPopAttrib();
		}
		// When clicked
		if (mouseState == false && LMouse_down_boolean == false && mouseType == 0)
		{
			if (showHelp == false)
				showHelp = true;
			else showHelp = false;

			LMouse_down_boolean = true;
		}
		else if (mouseState == true)
		{
			LMouse_down_boolean = false;
		}
	}
	else
	{
		button1[3] = NULL;
		glPushMatrix();
		glTranslatef(850, 5, 0);
		glScalef(1.3, 1.3 * h / 745, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[3].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();
	}
}

void HUD::renderOptionsButton()
{
	// When mouse over
	if(mouseX > (940 * w / 1024) && mouseX < (990 * w / 1024) && mouseY > (5 * h / 745) && mouseY < (55 * h / 745) && showHelp != true && showInventory != true && showConfirmUseScreen != true)
	{
		if (button1[4] == NULL)//this type of code will only play once
			button1[4] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
		if (button1[4]->getIsPaused() == true)
			button1[4]->setIsPaused(false);
		glPushMatrix();
		glTranslatef(940, 5, 0);
		glScalef(1.3, 1.3 * h / 745, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[2].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		float mouseX_new = (float) mouseX * (1024 / (float) w);
		float mouseY_new = (float) mouseY * (745 / (float) h);

		glLoadIdentity();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glColor3f(1, 1, 0);
			printw(mouseX_new - 10, mouseY_new + 45, 0, "Options");
		glPopAttrib();

		if (mouseState == false && LMouse_down_boolean == false && mouseType == 0)
		{
			if (showOptions == false)
			{
				showOptions = true;
			}
			else
			{
				showOptions = false;
			}

			LMouse_down_boolean = true;
		}
		else if (mouseState == true)
		{
			LMouse_down_boolean = false;
		}
	}
	else
	{
		button1[4] = NULL;
		glPushMatrix();
		glTranslatef(940, 5, 0);
		glScalef(1.3, 1.3 * h / 745, 1);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[1].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,40);
				glTexCoord2f(1,0); glVertex2f(40,40);
				glTexCoord2f(1,1); glVertex2f(40,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();
	}
}

void HUD::renderInventoryButton()
{
	// When mouse over
	if(mouseX > (770 * w / 1024) && mouseX < (870 * w / 1024) && mouseY > (630 * h / 745) && mouseY < (740 * h / 745) && showHelp != true && showConfirmUseScreen != true)
	{
		if (button1[5] == NULL)//this type of code will only play once
			button1[5] = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
		if (button1[5]->getIsPaused() == true)
			button1[5]->setIsPaused(false);
		glPushMatrix();
		glTranslatef(770, 685, 0);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[10].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,105);
				glTexCoord2f(1,0); glVertex2f(105,105);
				glTexCoord2f(1,1); glVertex2f(105,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();

		float mouseX_new = (float) mouseX * (1024 / (float) w);
		float mouseY_new = (float) mouseY * (745 / (float) h);

		if (showInventory == false)
		{
			glLoadIdentity();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1, 1, 0);
				printw(mouseX_new, mouseY_new + 87.5f, 0, "Inventory");
			glPopAttrib();
		}
		else
		{
			glLoadIdentity();
			glPushAttrib(GL_ALL_ATTRIB_BITS);
				glColor3f(1, 1, 0);
				printw(mouseX_new, mouseY_new + 87.5f, 0, "Close Inventory");
			glPopAttrib();
		}


		// When clicked
		if (mouseState == false && LMouse_down_boolean == false && mouseType == 0)
		{
			if (showInventory == false)
				showInventory = true;
			else
			{
				CPlayState::Instance()->thePlayer->myInventory->resetCraftingSlots();
				CPlayState::Instance()->thePlayer->myInventory->setAllItemsToBeOld();
				CPlayState::Instance()->thePlayer->myInventory->resetAllItemsSelectedForCrafting();

				showInventory = false;
			}

			LMouse_down_boolean = true;
		}
		else if (mouseState == true)
		{
			LMouse_down_boolean = false;
		}
	}
	else
	{
		button1[5] = NULL;
		glPushMatrix();
		glTranslatef(770, 685, 0);
		glEnable( GL_TEXTURE_2D );
		glEnable( GL_BLEND );
			glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glBindTexture( GL_TEXTURE_2D, HUDtex[9].texID );
			glBegin(GL_QUADS);
				glTexCoord2f(0,1); glVertex2f(0,0);
				glTexCoord2f(0,0); glVertex2f(0,105);
				glTexCoord2f(1,0); glVertex2f(105,105);
				glTexCoord2f(1,1); glVertex2f(105,0);
			glEnd();
		glDisable( GL_BLEND );
		glDisable( GL_TEXTURE_2D );
		glPopMatrix();
	}
}

void HUD::renderMisc(void)
{
	// Top bar
	glPushMatrix();
	glScalef(25.6 * w / 1024, 1.7, 1);
	glEnable( GL_TEXTURE_2D );
	glEnable( GL_BLEND );
		glColor4f(0.3f, 0.3f, 0.3f, 1);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
		glBegin(GL_QUADS);
			glTexCoord2f(0,1); glVertex2f(0,0);
			glTexCoord2f(0,0); glVertex2f(0,40);
			glTexCoord2f(1,0); glVertex2f(40,40);
			glTexCoord2f(1,1); glVertex2f(40,0);
		glEnd();
	glDisable( GL_BLEND );
	glDisable( GL_TEXTURE_2D );
	glPopMatrix();

	// Bottom bar
	glPushMatrix();
	glTranslatef(0, 675, 0);
	glScalef(25.6 * w / 1024, 3.3 * h / 745, 1);
	glEnable( GL_TEXTURE_2D );
	glEnable( GL_BLEND );
		glColor4f(0.3f, 0.3f, 0.3f, 1);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
		glBegin(GL_QUADS);
			glTexCoord2f(0,1); glVertex2f(0,0);
			glTexCoord2f(0,0); glVertex2f(0,40);
			glTexCoord2f(1,0); glVertex2f(40,40);
			glTexCoord2f(1,1); glVertex2f(40,0);
		glEnd();
	glDisable( GL_BLEND );
	glDisable( GL_TEXTURE_2D );
	glPopMatrix();

	// Mid-bottom bar
	glPushMatrix();
	glTranslatef(380, 675, 0);
	glScalef(6, 3.3 * h / 745, 1);
	glEnable( GL_TEXTURE_2D );
	glEnable( GL_BLEND );
		glColor4f(0.2f, 0.2f, 0.2f, 1);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glBindTexture( GL_TEXTURE_2D, HUDtex[0].texID );
		glBegin(GL_QUADS);
			glTexCoord2f(0,1); glVertex2f(0,0);
			glTexCoord2f(0,0); glVertex2f(0,40);
			glTexCoord2f(1,0); glVertex2f(40,40);
			glTexCoord2f(1,1); glVertex2f(40,0);
		glEnd();
	glDisable( GL_BLEND );
	glDisable( GL_TEXTURE_2D );
	glPopMatrix();
}

void HUD::renderHUD (int health, int detection_state, int level, int mouseX, int mouseY, bool mouseState, int mouseType, int w, int h, Inventory *theInventory, string equipped)
{
	if (health <= 100 && health >= 0)
		this->health = health;
	else if (health > 100) 
		this->health = 100;
	else if (health < 0)
		this->health = 0;

	this->detection_state = detection_state;
	this->level = level;

	this->mouseX = mouseX;
	this->mouseY = mouseY;
	this->mouseState = mouseState;
	this->mouseType = mouseType;

	this->w = w;
	this->h = h;

	HUDInventory = theInventory;
	currEquipped = equipped;

	if (volume == 0)
		mutemusic = true;
	else
		mutemusic = false;

	HelpScreen();
	OptionsScreen();
	InventoryScreen();

	if (LMouse_down_boolean == false)
	{
		ConfirmUseScreen(confirm_temp_item_name, confirm_temp_item_id);
		ConfirmDiscardScreen(confirm_temp_item_name, confirm_temp_item_id);
	}

	if (showOptions != true)
	{
		renderMisc();

		drawHealthMeter ();
		drawDetectionStatus();

		renderCurrentWeapon();
		//renderLevel();
		renderHelpButton();
		renderOptionsButton();
		renderInventoryButton();

		CPlayState::Instance()->game_pause = true;
	}
	else
		CPlayState::Instance()->game_pause = false;
}