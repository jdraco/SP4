#include "GameEndState.h"

CGameEndState* CGameEndState::theGameEndState;

CGameEndState::CGameEndState(void)
	//:EndGame(true)
	:type(0)
{
}

CGameEndState::CGameEndState(int type)
	//:EndGame(true)
{
	this->type = type;
}

CGameEndState::~CGameEndState(void)
{
}


void CGameEndState::Init()
{
	theGlobal = CGlobal::getInstance();
	font = new CFont();
	theCamera = Camera::getInstance();
	//myMenu = new GameMenu();
	cout << "CGameEndState::Init\n" << endl;
}

void CGameEndState::Cleanup()
{
	cout << "CGameEndState::Cleanup\n" << endl;
}

void CGameEndState::Pause()
{
	cout << "CGameEndState::Pause\n" << endl;
}

void CGameEndState::Resume()
{
	cout << "CGameEndState::Resume\n" << endl;
}

void CGameEndState::HandleEvents(CGameStateManager* theGSM)
{
	//theGSM->PopState();
	theGSM->Cleanup();
	theGSM->PushState(CMenuState::Instance());
}

void CGameEndState::Update(CGameStateManager* theGSM) 
{
	
	if(theGlobal->MouseState == false) //mouse click up
	{
		if(CGameEndState::Instance()->EndGame == true)
		{				
			theGSM->Cleanup();
			theGSM->PushState(CMenuState::Instance());
		}
				
		else				
		{		

			theGSM->PopState();
		}
	}

	cout << "CGameEndState::Update\n" << endl;

}

void CGameEndState::Draw(CGameStateManager* theGSM) 
{
	/*
	theCamera->SetHUD(true);

	//glColor3f(0,0,1);
	//drawString();
	myMenu->renderMenu(theGlobal->MousePos.x,theGlobal->MousePos.y,theGlobal->MouseState,glutGet(GLUT_WINDOW_WIDTH),glutGet(GLUT_WINDOW_HEIGHT));

	theCamera->SetHUD(false);
	*/
	if(type == -1)
		theGSM->PushState(CMenuState::Instance());
	else if(type == 0)
	{
		//theGlobal->currentlevel = 0;
		theCamera->SetHUD(true);
		font->Render("DEFEAT",
			Vector3D(512/2-30, 360,0),Vector3D(1,0,0), 5);
		font->Render("MOUSECLICK TO CONTINUE",
			Vector3D(300, 500,0),Vector3D(1,1,0), 1);
		theCamera->SetHUD(false);
	}
	else if(type == 1)
	{
		//theGlobal->currentlevel = 0;
		theCamera->SetHUD(true);
		font->Render(" WIN",
			Vector3D(512/2, 360,0),Vector3D(1,0,0), 5);
		font->Render("MOUSECLICK TO CONTINUE",
			Vector3D(300, 500,0),Vector3D(1,1,0), 1);
		theCamera->SetHUD(false);
	}
	cout << "CGameEndState::Draw\n" << endl;
}