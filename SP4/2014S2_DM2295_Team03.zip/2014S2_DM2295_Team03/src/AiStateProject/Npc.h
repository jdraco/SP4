#pragma once
#include <iostream>
#include"Goodies.h"
#include "Global.h"
#include<string>
#include "Font.h"
#include "Inventory.h"

class CNpc : public CVariable
{
public:
	
	CNpc();
	~CNpc();
	void render();
	void init(bool shopkeeper, string msg, float X, float Y);
	void Update(Vector3D PlayerPos,Vector3D PlayerDir, bool interaction);
	void Popup();
	void Msg();
	bool isAshopkeeper;//check if is shop keeper
	string conversation;//conversation string
	bool PlayerTalk;//if player is interacting with u
	Inventory *inventory;
	bool getShopOpen();
	void setShopOpen(bool shop);
private:
	CGlobal *theGlobal;
	int dir;

	bool shopOpen;// if shop is opened
	CFont *font;
	CSprite*NpcSprite;
	TextureImage Npctex[10];
};
