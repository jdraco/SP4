#include <iostream>
using namespace std;

#include "GameStateManager.h"
#include "playstate.h"
#include "menustate.h"

CMenuState CMenuState::theMenuState;

void CMenuState::Init()
{
	theGlobal = CGlobal::getInstance();
	theCamera = Camera::getInstance();
	myMenu = new GameMenu();
	//background = NULL;
	//cout << "CMenuState::Init\n" << endl;
}

void CMenuState::Cleanup()
{
	//cout << "CMenuState::Cleanup\n" << endl;
}

void CMenuState::Pause()
{
	//cout << "CMenuState::Pause\n" << endl;
}

void CMenuState::Resume()
{
	//cout << "CMenuState::Resume\n" << endl;
}

void CMenuState::HandleEvents(CGameStateManager* theGSM)
{
	//CPlayState::DeleteInstance();
	background->setIsPaused(true);
	background = NULL;
	theGSM->ChangeState(CPlayState::NewInstance());
	//theGSM->ChangeState(CPlayState::Instance());
}

void CMenuState::Update(CGameStateManager* theGSM) 
{
	if (background == NULL)//this type of code will only play once
		background = theGlobal->SoundEngine->play2D("Sound/background.mp3", true, true);
	if (background->getIsPaused() == true)
		background->setIsPaused(false);
	if (background->isFinished())
		background = NULL;

	//cout << "CMenuState::Update\n" << endl;
	//option button
	if (theGlobal->MousePos.x > 312.5 * glutGet(GLUT_WINDOW_WIDTH) / 800 && theGlobal->MousePos.x < 485 * glutGet(GLUT_WINDOW_WIDTH) / 800 && theGlobal->MousePos.y > 345 * glutGet(GLUT_WINDOW_HEIGHT) / 600 && theGlobal->MousePos.y < 390 * glutGet(GLUT_WINDOW_HEIGHT) / 600&&myMenu->show_options==false)
	{
		if (button == NULL)//this type of code will only play once
			button = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
		if (button->getIsPaused() == true)
			button->setIsPaused(false);


	}

	else if (theGlobal->MousePos.x > 312.5 * glutGet(GLUT_WINDOW_WIDTH) / 800 && theGlobal->MousePos.x < 485 * glutGet(GLUT_WINDOW_WIDTH) / 800 && theGlobal->MousePos.y > 270 * glutGet(GLUT_WINDOW_HEIGHT) / 600 && theGlobal->MousePos.y < 315 * glutGet(GLUT_WINDOW_HEIGHT) / 600&&myMenu->show_options==false)
	{
		if (button == NULL)//this type of code will only play once
			button = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
		if (button->getIsPaused() == true)
			button->setIsPaused(false);
	}
	//quit button
	else if (theGlobal->MousePos.x > 312.5 * glutGet(GLUT_WINDOW_WIDTH) / 800 && theGlobal->MousePos.x < 485 * glutGet(GLUT_WINDOW_WIDTH) / 800 && theGlobal->MousePos.y > 470 * glutGet(GLUT_WINDOW_HEIGHT) / 600 && theGlobal->MousePos.y < 515 * glutGet(GLUT_WINDOW_HEIGHT) / 600&&myMenu->show_options==false)
	{
		if (button == NULL)//this type of code will only play once
			button = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
		if (button->getIsPaused() == true)
			button->setIsPaused(false);
	}
	// Lower volume button
	else if (theGlobal->MousePos.x > 405 * glutGet(GLUT_WINDOW_WIDTH) / 1024 && theGlobal->MousePos.x < 445 * glutGet(GLUT_WINDOW_WIDTH) / 1024 && theGlobal->MousePos.y > 245 * glutGet(GLUT_WINDOW_HEIGHT) / 745 && theGlobal->MousePos.y < 285 * glutGet(GLUT_WINDOW_HEIGHT) / 745 && myMenu->show_options == true)
	{
		if (button == NULL)//this type of code will only play once
			button = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
		if (button->getIsPaused() == true)
			button->setIsPaused(false);
		/*if (button->isFinished())
			button = NULL;*/
	}
	
	// Increase volume button
	else if (theGlobal->MousePos.x > 575 * glutGet(GLUT_WINDOW_WIDTH) / 1024 && theGlobal->MousePos.x < 610 * glutGet(GLUT_WINDOW_WIDTH) / 1024 && theGlobal->MousePos.y > 245 * glutGet(GLUT_WINDOW_HEIGHT) / 745 && theGlobal->MousePos.y < 285 * glutGet(GLUT_WINDOW_HEIGHT) / 745 && myMenu->show_options == true)
	{
		if (button == NULL)//this type of code will only play once
			button = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
		if (button->getIsPaused() == true)
			button->setIsPaused(false);
			
	}
	else if (theGlobal->MousePos.x > 400 * glutGet(GLUT_WINDOW_WIDTH) / 1024 && theGlobal->MousePos.x < 620 * glutGet(GLUT_WINDOW_WIDTH) / 1024 && theGlobal->MousePos.y > 520 * glutGet(GLUT_WINDOW_HEIGHT) / 745 && theGlobal->MousePos.y < 560 * glutGet(GLUT_WINDOW_HEIGHT) / 745 && myMenu->show_options == true)
	{
		if (button == NULL)//this type of code will only play once
			button = theGlobal->SoundEngine->play2D("Sound/mouseon.wav", false, true);
		if (button->getIsPaused() == true)
			button->setIsPaused(false);

	}
	else
		button = NULL;

	theGlobal->SoundEngine->setSoundVolume((float) ((float)(myMenu->volume)/100.0f));
}

void CMenuState::Draw(CGameStateManager* theGSM) 
{
	theCamera->SetHUD(true);

	//glColor3f(0,0,1);
	//drawString();
	myMenu->renderMenu(theGlobal->MousePos.x,theGlobal->MousePos.y,theGlobal->MouseState,glutGet(GLUT_WINDOW_WIDTH),glutGet(GLUT_WINDOW_HEIGHT));

	theCamera->SetHUD(false);
	
	//cout << "CMenuState::Draw\n" << endl;
}

void CMenuState::drawString(){



	glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
		//  Print the FPS to the window
		glColor3f( 1.0f, 1.0f, 1.0f);
		//printw (25.0, 25.0, 0, "FPS: %4.2f", fps);

		printw (350.0, 200.0, 0, "Menu Screen");

		//printw (25.0, 75.0, 0, "Cubes Gotten: %4d", theGlobal->InGameTime->GetCurrent());
	glPopAttrib();
}
