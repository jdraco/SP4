#pragma once
#include "Global.h"
#include "GameMenu.h"

#include "gamestate.h"
#include "MenuState.h"
#include "PlayState.h"


class CGameEndState : public CGameState
{
private:
	CGlobal* theGlobal;
	CFont* font;
	Camera *theCamera;
	int type;
public:
	bool EndGame;


	static CGameEndState *theGameEndState;

	void Init();
	void Cleanup();

	void Pause();
	void Resume();

	void HandleEvents(CGameStateManager* theGSM);
	void Update(CGameStateManager* theGSM);
	void Draw(CGameStateManager* theGSM);

	static CGameEndState* Instance() {
		return theGameEndState;
	}
	static CGameEndState* NewInstance(int type) {
		theGameEndState = new CGameEndState(type);
		return theGameEndState;
	}

	CGameEndState(void);
	CGameEndState(int type);
	~CGameEndState(void);
};

