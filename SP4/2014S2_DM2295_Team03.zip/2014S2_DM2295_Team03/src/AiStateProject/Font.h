#pragma once
#include "Function.h"
#include "Variable.h"
#define O_SMALL_TEXT 10
#define O_BIG_TEXT 20

class CFont : public CVariable
{
public:
	CFont(void);
	~CFont(void);
	void Render(string text, Vector3D pos, Vector3D color,float scale);
	void RenderAlphabet(char text);
	int down;
private:
	float SMALL_TEXT;
	float BIG_TEXT;
};