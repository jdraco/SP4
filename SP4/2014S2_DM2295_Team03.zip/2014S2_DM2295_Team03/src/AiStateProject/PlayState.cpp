#include <iostream>
using namespace std;

#include "gamestate.h"
#include "GameStateManager.h"
#include "playstate.h"
#include "menustate.h"

CPlayState* CPlayState::thePlayState;

void CPlayState::Init()
{
	cubeCount = 0;
	
	thePlayer = CPlayerInfo::getInstance();
	thePlayer->Init();
	
	/*theNpc = new CNpc();
	theNpc->init(true,"Hi,how/may i/help you?",540, 2100);*/
	font = new CFont();
	hud = new HUD();
	LoadTGA(&Tex[0], "Texture/Conditon/defeat.tga");
	LoadTGA(&Tex[1], "Texture/Conditon/defeat.tga");
	sfx =NULL;

	CountDown = 0;
	CountDownWin = 0;

	game = NULL;
	theCamera = Camera::getInstance();

	theGlobal = CGlobal::getInstance();
	//Set Up Map
	theGlobal->theMap = CMap::getInstance();
	theGlobal->theMap->mapInit = false;
	theGlobal->theMap->Init(MAP_SCREEN_HEIGHT, MAP_SCREEN_WIDTH, RESOLUTION_HEIGHT*3, RESOLUTION_WIDTH*2, TILE_SIZE);
	currentMap = theGlobal->theMap->STARTING_MAP;
	string MapName = "MapDesign" + static_cast<ostringstream*>(&(ostringstream()<<currentMap))->str() + ".csv";
	theGlobal->theMap->LoadTextures();
	if (!theGlobal->theMap->LoadMap(MapName))
		cout << "Map Failed" << endl;

	theGlobal->theMap->mapInit = true;

	theGlobal->theMap->theBorder = new CMap;
	theGlobal->theMap->theBorder->Init(MAP_SCREEN_HEIGHT, MAP_SCREEN_WIDTH, RESOLUTION_HEIGHT*2, RESOLUTION_WIDTH*2, TILE_SIZE);
	string BorderName = "Border" + static_cast<ostringstream*>(&(ostringstream()<<MAP_SCREEN_WIDTH))->str() + ".csv";
	if (!theGlobal->theMap->theBorder->LoadMap(BorderName))
		cout << "Border Failed" << endl; //Init Failed
	theGlobal->theMap->theBorder->mapInit = true;


	theGlobal->InGameTime->SetCurrent();
	theGlobal->InGameTime->SetTotalTime(60);
	lastTime = (float) theGlobal->InGameTime->GetCurrent();
	 
	 //Player init
	LoadLevel(currentMap);

	ScanMap();

	Debug = false;
	//thePlayer->Init();
	for(unsigned i = 0; i < 255; i++)
		prevKey[i] = false;

	game_pause = true;
	main_menu = false;
	InitNpc();
	theNpc = new CNpc();
	theNpc->init(true,"Hi,how/may i/help you?",npcPos[theGlobal->currentlevel-1][0], npcPos[theGlobal->currentlevel-1][1]);
}

void CPlayState::InitNpc()
{
	npcPos[0][0] = 540;
	npcPos[0][1] = 2100;

	npcPos[1][0] = 540;
	npcPos[1][1] = 1232;

	npcPos[2][0] = 1500;
	npcPos[2][1] = 1618;

	npcPos[3][0] = 540;
	npcPos[3][1] = 2054;

	npcPos[4][0] = 540;
	npcPos[4][1] = 2054;

	npcPos[5][0] = 740;
	npcPos[5][1] = 1132;

	npcPos[6][0] = 540;
	npcPos[6][1] = 2054;

	npcPos[7][0] = 540;
	npcPos[7][1] = 2054;
}

void CPlayState::Cleanup()
{
	
	thePlayer->myInventory->emptyAllSlots();
	thePlayState = new CPlayState();
	//delete &thePlayState;
}

void CPlayState::Pause()
{
	//cout << "CPlayState::Pause\n" << endl;
}

void CPlayState::Resume()
{
	//cout << "CPlayState::Resume\n" << endl;
}

void CPlayState::HandleEvents(CGameStateManager* theGSM)
{
	game->setIsPaused(true);
	game = NULL;
	if(main_menu)
	{
		theGlobal->currentlevel = 1;
		theGSM->PushState(CGameEndState::NewInstance(-1));
	}
	else if (thePlayer->getHealth().current <= 0)
	{
		theGSM->PushState(CGameEndState::NewInstance(0));
		CGameEndState::Instance()->EndGame = false;
		//theGlobal->currentlevel = 1;
		theGlobal->SoundEngine->play2D("Sound/lose.wav", false);
		thePlayer->setHP(100);
		theGlobal->theMap->Level_mapOffset(theGlobal->currentlevel);
		SCamList.clear();//gg
		GuardList.clear();
		delete theNpc;
		theNpc = new CNpc();
		theNpc->init(true,"Hi,how/may i/help you?",npcPos[theGlobal->currentlevel-1][0], npcPos[theGlobal->currentlevel-1][1]);
		for(unsigned i = 0; i < 20; i++)
			Paths[i].Points.clear();
		ScanMap();
	}
	else if(theGlobal->currentlevel != MAX_LEVEL)
	{
		theGlobal->SoundEngine->play2D("Sound/win.mp3", false);
		theGSM->PushState(CGameEndState::NewInstance(1));
		CGameEndState::Instance()->EndGame = false;
		CountDownWin = 0;
	}
	else
	{
		theGlobal->SoundEngine->play2D("Sound/win.mp3", false);
		theGlobal->currentlevel = 1;
		theGSM->PushState(CGameEndState::NewInstance(1));
		CGameEndState::Instance()->EndGame = false;
	}
}

void CPlayState::Update(CGameStateManager* theGSM)
{
	if (game == NULL)//this type of code will only play once
		game = theGlobal->SoundEngine->play2D("Sound/game.mp3", true, true);
	if (game->getIsPaused() == true)
		game->setIsPaused(false);
	if (game->isFinished())
		game = NULL;

	if(main_menu)
		HandleEvents(theGSM);

	if (game_pause == true)
	{
		if(CountDown >= 1)
		{
			hud->level = theGlobal->currentlevel;
			HandleEvents(theGSM);
		}
		if(CountDown == 0)
		{
			
			//Constrain Hero to middle of screen (unless he reaches the border)
			ConstrainPlayer((const int)(MAP_SCREEN_WIDTH*0.5+LEFT_BORDER), (const int)(MAP_SCREEN_WIDTH*0.5+LEFT_BORDER), 
						(const int)(MAP_SCREEN_HEIGHT*0.5+BOTTOM_BORDER), (const int)(MAP_SCREEN_HEIGHT*0.5+BOTTOM_BORDER),
						1.0f, theGlobal->theMap->mapOffset_x, theGlobal->theMap->mapOffset_y);
	
			theGlobal->theMap->Update();

			theGlobal->InGameTime->Update();

			//guardupdate
			for(unsigned a = 0; a < GuardList.size(); ++a)
			{
				CGuard *guard = GuardList[a];
				guard->Update();
			}

			for(unsigned a = 0; a < SCamList.size(); ++a)
			{
				CSecurityCam *CAM = SCamList[a];
				CAM->SetPlayerPos(thePlayer->GetPos());
				CAM->Update();

			}
			/*
			if(theGlobal->InGameTime->GetCurrent() < lastTime-3){ 
			int A = theGlobal->RG.getImmediateResult(0,theGlobal->theMain.size()-1);
			CGroup *go = theGlobal->theMain[A];
			go->SetPos(go->GetPos().x,go->GetPos().y+5,go->GetPos().z);
			go->obtainable = true;
			//Wait for 3sec more
			lastTime = theGlobal->InGameTime->GetCurrent();
			}
			*/
			//theCamera->SetPlayerInfo(thePlayer->GetPos(), thePlayer->GetRot());
			thePlayer->SetGuardList(GuardList);
			thePlayer->SetCamList(SCamList);
			if(!theGlobal->lock->active)
				thePlayer->Update();
			if(theGlobal->myKeys['e'] || theGlobal->myKeys['E'])
			{
				if(!prevKey['e'] && theGlobal->myKeys['e'] || !prevKey['E'] && theGlobal->myKeys['E'])
				theNpc->Update(thePlayer->GetPos(),thePlayer->GetDir(),true);
			}
			/*else
			{
				prevE = false;
			}*/
			if(theGlobal->lock->active)//inventory add item type lockpick
			{
				bool movelock = false;
				float dirV = 0;
				if(theGlobal->myKeys[' '])
					movelock = true;
				if(theGlobal->myKeys[27])
					theGlobal->lock->active = false;
				if(theGlobal->myKeys['a'] || theGlobal->myKeys['A'])
					dirV = -1;
				if(theGlobal->myKeys['d'] || theGlobal->myKeys['D'] )
					dirV = 1;

				int lockReturn = theGlobal->lock->Update(dirV,movelock);
				if(lockReturn == 1)
				{	
					theGlobal->lock->active = false;
					theGlobal->lock->Reset(true, 30, 100);
					if(theGlobal->Unlock(thePlayer->GetPos() , thePlayer->GetDir(), theGlobal->theMap, 
						theGlobal->theMap->mapOffset_x, theGlobal->theMap->mapOffset_y,lockReturn))
					{
						//if (sfx == NULL)//this type of code will only play once
						//sfx = theGlobal->SoundEngine->play2D("Sound/load.mp3", false, true);
						//if (sfx->getIsPaused() == true)
						//sfx ->setIsPaused(false);
						int random_loot = rand()%6+1;
						thePlayer->myInventory->addItem(random_loot);
					}
					else
					{
						sfx = NULL;
					}
				}
				if(lockReturn == -1)
				{	
					thePlayer->myInventory->removeItem(7);
					if(!thePlayer->myInventory->findItem("Lockpick"))
						theGlobal->lock->active = false;
					theGlobal->lock->Reset(false, 0 ,0);
				}
			}
			for(unsigned a = 0; a < MoneyList.size(); ++a)
			{
				MoneyList[a]->Timeleft--;
				MoneyList[a]->Pos.y--;
				if(MoneyList[a]->Timeleft <= 0)
					MoneyList.erase(MoneyList.begin() + a);
			}
		}
		//cout << "CPlayState::Update\n" << endl;
	}
	for(unsigned i = 0; i < 255; i++)
		prevKey[i] = theGlobal->myKeys[i];

	theGlobal->SoundEngine->setSoundVolume((float) ((float)(hud->volume)/100.0f));

	
	if (CountDownWin >= 1)
	{
		SCamList.clear();//gg
		GuardList.clear();
		delete theNpc;
		theNpc = new CNpc();
		theNpc->init(true,"Hi,how/may i/help you?",npcPos[theGlobal->currentlevel-1][0], npcPos[theGlobal->currentlevel-1][1]);
		for(unsigned i = 0; i < 20; i++)
			Paths[i].Points.clear();
		ScanMap();
		theGlobal->next_level = false;

		CountDownWin = 0;

		HandleEvents(theGSM);
	}
}

void CPlayState::Draw(CGameStateManager* theGSM)
{
	/*
	for(unsigned a = 0; a < theGlobal->theMain.size(); ++a)
	{
		CGroup *go = theGlobal->theMain[a];
			
		if(go->rendered == false)
		{
			if(go->active == true)
			{
				go->Draw();
			}
		}
	}
	*/
		
	theCamera->SetHUD(true);
	glColor3f(1,1,1);
	LoadLevel(currentMap);
	theNpc->Popup();
	theNpc->render();
	

	for(unsigned a = 0; a < SCamList.size(); ++a)
	{
		CSecurityCam *CAM = SCamList[a];
		if(CAM->active == true)
		{
			CAM->Render();
		}
	}
	thePlayer->Render();
	for(unsigned a = 0; a < GuardList.size(); ++a)
	{
		CGuard *guard = GuardList[a];
		if(guard->active == true)
		{
			guard->Render();
			if(guard->GetState() == CGuard::ATTACK || guard->GetState() == CGuard::CHASE)
				hud->detection_state = 1;
			if(guard->loot)
			{
				guard->active = hud->InventoryScreen(guard->inventory, true, theGlobal->MouseState,theGlobal->MouseType);
				if(!guard->active)
				{
					delete guard->inventory;
					int moneyG  = rand()%30+17;
					thePlayer->setMoney(thePlayer->getMoney()+moneyG) ;//sss
					stringstream ss;
					ss << moneyG;
					string sMoney = ss.str() + "G";
					DmgFont* tempMoney = new DmgFont(sMoney, guard->GetPos(),1,Vector3D(1,1,0), 50);
					MoneyList.push_back(tempMoney);
					theGlobal->SoundEngine->play2D("Sound/getmoney2.mp3");
				}
			}
		}
	}
	for(unsigned a = 0; a < MoneyList.size(); ++a)
	{
		font->Render(MoneyList[a]->DMG,MoneyList[a]->Pos,MoneyList[a]->col,MoneyList[a]->size);
	}
	theGlobal->theMap->RenderMapBorder();
	if(theGlobal->lock->active)
		theGlobal->lock->Render();
	else if(theGlobal->checkInteractableTiles(thePlayer->GetPos(),thePlayer->GetDir(),theGlobal->theMap,theGlobal->theMap->mapOffset_x,theGlobal->theMap->mapOffset_y))
		font->Render("E TO INTERACT",
		Vector3D(thePlayer->GetPos().x+50,thePlayer->GetPos().y,0),Vector3D(0,0,1),1);
	//font->Render("Controls/WASD to move/E to interact or use weap/t y u i for debug weap/Click on bag for inventory/Left click to use item/Middle click to discard item/Right click to craft item",
	//Vector3D(670, 70,0),Vector3D(1,1,1));
	if(Debug)
	DebugInfo();
	hud->renderHUD(thePlayer->getHP(),hud->detection_state, 1, theGlobal->MousePos.x,theGlobal->MousePos.y,theGlobal->MouseState,theGlobal->MouseType,glutGet(GLUT_WINDOW_WIDTH),glutGet(GLUT_WINDOW_HEIGHT),thePlayer->myInventory,thePlayer->getCurrEquipped());
	stringstream ss;
	ss << thePlayer->getMoney();
	string str = "Money " + ss.str();
	font->Render(str,
		Vector3D(850,750,0),Vector3D(1,1,0),1);
	if(theNpc->getShopOpen())
	{
		theNpc->setShopOpen(hud->InventoryScreen(theNpc->inventory, false,theGlobal->MouseState,theGlobal->MouseType));
	}
	stringstream cl;
	cl << theGlobal->currentlevel;
	string sLevel = "Level " + cl.str();
	font->Render(sLevel,
	Vector3D(480,32,0),Vector3D(0,1,0),1);
	if (theGlobal->currentlevel > MAX_LEVEL || theGlobal->next_level && theGlobal->currentlevel != 1 || thePlayer->getHealth().current <= 0 )
		End(0,1);

	//cout << theGlobal->currentlevel << endl;
	
	theCamera->SetHUD(false);
	

	//cout << "CPlayState::Draw : " << counter << "\n" << endl;
}
void CPlayState::DebugInfo()
{
	glPushMatrix();
	glTranslatef(800, 170, 0);
	glColor4f(0, 0,0, 1);
	glBegin(GL_QUADS);
	glTexCoord2f(0,1); 
	glVertex2f(-150,-150);
	glTexCoord2f(0,0); 
	glVertex2f(-150,100);
	glTexCoord2f(1,0); 
	glVertex2f(150,100);
	glTexCoord2f(1,1); 
	glVertex2f(150,-150);
	glEnd();
	glPopMatrix();
	font->Render("Controls/WASD to move/E to interact or use weap/t y u i for debug weap/Click on bag for inventory/Left click to use item/Middle click to discard item/Right click to craft item",
		Vector3D(670, 70,0),Vector3D(1,1,1),1);
}
void CPlayState::drawString()
{
	//  Load the identity matrix so that FPS string being drawn
	//  won't get animates
	glLoadIdentity ();
		glPushAttrib(GL_ALL_ATTRIB_BITS);
		//  Print the FPS to the window
		glColor3f( 1.0f, 1.0f, 1.0f);
		//printw (25.0, 25.0, 0, "FPS: %4.2f", fps);

		printw (25.0, 50.0, 0, "Time Left: %4d", theGlobal->InGameTime->GetCurrent());
		printw (25.0, 75.0, 0, "Cube Gotten: %4d", cubeCount);

		//printw (25.0, 75.0, 0, "Cubes Gotten: %4d", theGlobal->InGameTime->GetCurrent());
	glPopAttrib();
}

void CPlayState::End(int tex , int end)
{
	if(end == 0)
	{
		glPushMatrix();
		//glTranslatef(glutGet(GLUT_WINDOW_WIDTH)/2,glutGet(GLUT_WINDOW_HEIGHT)/2,0);
		glTranslatef(0,0,0);
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glBindTexture(GL_TEXTURE_2D, Tex[tex].texID);
		glColor4f(1,1,1,CountDown);
		glBegin(GL_QUADS);
		glTexCoord2f(1,1); 
		glVertex2f(0,0);
		glTexCoord2f(1,0); 
		glVertex2f(0,glutGet(GLUT_WINDOW_HEIGHT)*1.2);
		glTexCoord2f(0,0); 
		glVertex2f(glutGet(GLUT_WINDOW_WIDTH),glutGet(GLUT_WINDOW_HEIGHT)*1.2);
		glTexCoord2f(0,1); 
		glVertex2f(glutGet(GLUT_WINDOW_WIDTH),0);
		glEnd();
		glPopMatrix();
		if(CountDown < 1)
		CountDown+=0.01;
	}
	else
	{
	glPushMatrix();
	//glTranslatef(glutGet(GLUT_WINDOW_WIDTH)/2,glutGet(GLUT_WINDOW_HEIGHT)/2,0);
	glTranslatef(0,0,0);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glBindTexture(GL_TEXTURE_2D, Tex[tex].texID);
	glColor4f(1,1,1,CountDownWin);
	glBegin(GL_QUADS);
	glTexCoord2f(1,1); 
	glVertex2f(0,0);
	glTexCoord2f(1,0); 
	glVertex2f(0,glutGet(GLUT_WINDOW_HEIGHT)*1.2);
	glTexCoord2f(0,0); 
	glVertex2f(glutGet(GLUT_WINDOW_WIDTH),glutGet(GLUT_WINDOW_HEIGHT)*1.2);
	glTexCoord2f(0,1); 
	glVertex2f(glutGet(GLUT_WINDOW_WIDTH),0);
	glEnd();
	glPopMatrix();

	if(CountDownWin < 1)
		CountDownWin+=0.01;
	}
	/*if(CountDown >= 1)
	{
		font->Render("DEFEAT",
		Vector3D(glutGet(GLUT_WINDOW_WIDTH)*0.5/2, glutGet(GLUT_WINDOW_HEIGHT)/3,0),Vector3D(1,0,0), 5);
		font->Render("PRESS ANY KEY TO CONTINUE",
		Vector3D(glutGet(GLUT_WINDOW_WIDTH)*0.6/2, glutGet(GLUT_WINDOW_HEIGHT)/2,0),Vector3D(1,1,0), 1);
	}*/
	
}
void CPlayState::LoadLevel(short level)
{
	//Set Current Level 
	currentMap = level;

	//Set Map
	theGlobal->theMap->theMap = theGlobal->theMap->MapL(level);

	//Re-Init Map
	if (!theGlobal->theMap->mapInit)
	{
		theGlobal->theMap->Init(MAP_SCREEN_HEIGHT, MAP_SCREEN_WIDTH, RESOLUTION_HEIGHT*3, RESOLUTION_WIDTH*2, TILE_SIZE);

		//Load Map from CSV
		string MapName = "MapDesign" + static_cast<ostringstream*>(&(ostringstream()<<theGlobal->theMap->theMap))->str() + ".csv";
		if (!theGlobal->theMap->LoadMap(MapName))
		{
			cout << "Loading Map \"MapDesign" << theGlobal->theMap->STARTING_MAP << ".csv\" instead." << endl << endl;
			LoadLevel(theGlobal->theMap->STARTING_MAP);
		}

		theGlobal->theMap->mapInit = true;
		return;
	}
	

	//Render Map
	theGlobal->theMap->RenderTileMap(theGlobal->theMap);
	//Render Map Border
	
}

void CPlayState::ConstrainPlayer(const int leftBorder, const int rightBorder, 
							  const int topBorder, const int bottomBorder, 
							  float timeDiff,
							  int& mapOffset_x, int& mapOffset_y)
{
	//Map's Scrolling Speed
	int ScrollSpeed = (int)(MAP_SCROLL_SPEED * timeDiff);

	if (thePlayer->GetPos().x < leftBorder)
	{
		mapOffset_x -= ScrollSpeed;

		//Scroll Enemies with Map
		for(unsigned a = 0; a < GuardList.size(); ++a)
		{
			CGuard *guard = GuardList[a];

			if (guard->active && mapOffset_x > 0)
			{
				guard->SetPos_x(guard->GetPos().x+ScrollSpeed);

				//Scroll Way Points
				
				for (short i = 0; i < (short)guard->OwnPath.Points.size(); ++i)
					guard->OwnPath.Points[i].setX (guard->OwnPath.Points[i].getX() + ScrollSpeed);
					
			}
		}

		for(unsigned a = 0; a < SCamList.size(); ++a)
		{
			CSecurityCam *Cam = SCamList[a];

			if (Cam->active && mapOffset_x > 0)
			{
				Cam->SetPos_x(Cam->GetPos().x+ScrollSpeed);
					
			}
		}

		//Set Limit
		if (mapOffset_x < 0)
			mapOffset_x = 0;
		//Player will be at the middle of the screen
		if (mapOffset_x != 0)
		{
			thePlayer->SetPos_x((float)leftBorder);
			for(int i = 0; i < thePlayer->GetBulletListSize(); i++)
			{
				float diffX = thePlayer->GetBullet(i)->GetPos().x - thePlayer->GetPos().x;
				thePlayer->GetBullet(i)->SetPosX((float)leftBorder+diffX);
			}
			float diffX = theNpc->GetPos().x - thePlayer->GetPos().x;
			theNpc->SetPos_x((float)leftBorder + diffX);
		}
		else if (thePlayer->GetPos().x < TILE_SIZE*3)
		{
			thePlayer->SetPos_x( TILE_SIZE*3 );
			for(int i = 0; i < thePlayer->GetBulletListSize(); i++)
			{
				float diffX = thePlayer->GetBullet(i)->GetPos().x - thePlayer->GetPos().x;
				thePlayer->GetBullet(i)->SetPosX(TILE_SIZE*3+diffX);
			}
			float diffX = theNpc->GetPos().x - thePlayer->GetPos().x;
			theNpc->SetPos_x(TILE_SIZE * 3 + diffX);
		}
	}

	else if (thePlayer->GetPos().x > rightBorder)
	{
		mapOffset_x += ScrollSpeed;
		
		//Scroll Enemies with Map
		for(unsigned a = 0; a < GuardList.size(); ++a)
		{
			CGuard *guard = GuardList[a];

			if (guard->active && mapOffset_x < RESOLUTION_WIDTH)
			{
				guard->SetPos_x(guard->GetPos().x-ScrollSpeed);

			for (short i = 0; i < (short)guard->OwnPath.Points.size(); ++i)
					guard->OwnPath.Points[i].setX (guard->OwnPath.Points[i].getX() - ScrollSpeed);
					
			}
		}	
		
		for(unsigned a = 0; a < SCamList.size(); ++a)
		{
			CSecurityCam *Cam = SCamList[a];

			if (Cam->active && mapOffset_x <RESOLUTION_WIDTH)
			{
				Cam->SetPos_x(Cam->GetPos().x-ScrollSpeed);
					
			}
		}
		//Set Limit
		if (mapOffset_x > RESOLUTION_WIDTH)
			mapOffset_x = RESOLUTION_WIDTH;

		//Player will be at the middle of the screen
		if (mapOffset_x < 999)
		{
			thePlayer->SetPos_x( (float)rightBorder );
			for(int i = 0; i < thePlayer->GetBulletListSize(); i++)
			{
				float diffX = thePlayer->GetBullet(i)->GetPos().x - thePlayer->GetPos().x;
				thePlayer->GetBullet(i)->SetPosX((float)rightBorder+diffX);
			}
			float diffX = theNpc->GetPos().x - thePlayer->GetPos().x;
			theNpc->SetPos_x((float)rightBorder + diffX);
		}
		else if (thePlayer->GetPos().x > RESOLUTION_WIDTH-TILE_SIZE*11)
		{
			thePlayer->SetPos_x( RESOLUTION_WIDTH-TILE_SIZE*11 );
			for(int i = 0; i < thePlayer->GetBulletListSize(); i++)
			{
				float diffX = thePlayer->GetBullet(i)->GetPos().x - thePlayer->GetPos().x;
				thePlayer->GetBullet(i)->SetPosX(RESOLUTION_WIDTH-TILE_SIZE*11+diffX);
			}
			float diffX = theNpc->GetPos().x - thePlayer->GetPos().x;
			theNpc->SetPos_x(RESOLUTION_WIDTH - TILE_SIZE * 11  + diffX);
		}
	}

	if (thePlayer->GetPos().y < topBorder)
	{
		mapOffset_y -= ScrollSpeed;
		
		for(unsigned a = 0; a < GuardList.size(); ++a)
		{
			CGuard *guard = GuardList[a];

			if (guard->active && mapOffset_y > 0)
			{
				guard->SetPos_y(guard->GetPos().y+ScrollSpeed);

				//Scroll Way Points
				
				for (short i = 0; i < (short)guard->OwnPath.Points.size(); ++i)
				{
					guard->OwnPath.Points[i].setY (guard->OwnPath.Points[i].getY() + ScrollSpeed);
					//cout << guard->OwnPath.Points[i].getY() << endl;
				}
			}
		}

		for(unsigned a = 0; a < SCamList.size(); ++a)
		{
			CSecurityCam *Cam = SCamList[a];

			if (Cam->active && mapOffset_x > 0)
			{
				Cam->SetPos_y(Cam->GetPos().y+ScrollSpeed);
					
			}
		}
		//Set Limit
		if (mapOffset_y < 0)
			mapOffset_y = 0;

		//Player will be at the middle of the screen
		if (mapOffset_y != 0)
		{
			thePlayer->SetPos_y( (float)topBorder );
			for(int i = 0; i < thePlayer->GetBulletListSize(); i++)
			{
				float diffY = thePlayer->GetBullet(i)->GetPos().y - thePlayer->GetPos().y;
				thePlayer->GetBullet(i)->SetPosY((float)topBorder+diffY);
			}
			float diffY = theNpc->GetPos().y - thePlayer->GetPos().y;
			theNpc->SetPos_y((float)topBorder + diffY);
		}
		else if (thePlayer->GetPos().y < TILE_SIZE*4)
		{
			thePlayer->SetPos_y(TILE_SIZE*4);
			for(int i = 0; i < thePlayer->GetBulletListSize(); i++)
			{
				float diffY = thePlayer->GetBullet(i)->GetPos().y - thePlayer->GetPos().y;
				thePlayer->GetBullet(i)->SetPosY(TILE_SIZE*4+diffY);
			}
			float diffY = theNpc->GetPos().y - thePlayer->GetPos().y;
			theNpc->SetPos_y(TILE_SIZE * 4 + diffY);
		}
	}

	else if (thePlayer->GetPos().y > bottomBorder)
	{
		mapOffset_y += ScrollSpeed;
		
		//Scroll Enemies with Map
		for(unsigned a = 0; a < GuardList.size(); ++a)
		{
			CGuard *guard = GuardList[a];

			if (guard->active && mapOffset_y < RESOLUTION_HEIGHT*2.15)
			{
				guard->SetPos_y(guard->GetPos().y-ScrollSpeed);

				
				//Scroll Way Points
				for (short i = 0; i < (short)guard->OwnPath.Points.size(); ++i)
					{
						guard->OwnPath.Points[i].setY (guard->OwnPath.Points[i].getY() - ScrollSpeed);
						//cout << guard->OwnPath.Points[i].getY() << endl;
					}
				
			}
		}
		
		
			for(unsigned a = 0; a < SCamList.size(); ++a)
			{
				CSecurityCam *Cam = SCamList[a];
				
				if (Cam->active && mapOffset_y < RESOLUTION_HEIGHT*2.15)
				{
					Cam->SetPos_y(Cam->GetPos().y-ScrollSpeed);
					
				}
			}
		//Set Limit
		if (mapOffset_y > RESOLUTION_HEIGHT*2.15)
			mapOffset_y = (int)(RESOLUTION_HEIGHT*2.15);

		//Player will be at the middle of the screen
		if (mapOffset_y < 1715) //1750
		{
			thePlayer->SetPos_y ((float)bottomBorder);
			for(int i = 0; i < thePlayer->GetBulletListSize(); i++)
			{
				float diffY = thePlayer->GetBullet(i)->GetPos().y - thePlayer->GetPos().y;
				thePlayer->GetBullet(i)->SetPosY((float)bottomBorder+diffY);
			}
			float diffY = theNpc->GetPos().y - thePlayer->GetPos().y;
			theNpc->SetPos_y((float)bottomBorder + diffY);
		}
		else if (thePlayer->GetPos().y > RESOLUTION_HEIGHT*2.15-TILE_SIZE*3)
		{
			thePlayer->SetPos_y ( RESOLUTION_HEIGHT*2.15-TILE_SIZE*3 );
			for(int i = 0; i < thePlayer->GetBulletListSize(); i++)
			{
				float diffY = thePlayer->GetBullet(i)->GetPos().y - thePlayer->GetPos().y;
				thePlayer->GetBullet(i)->SetPosY(RESOLUTION_HEIGHT*2.15-TILE_SIZE*3+diffY);
			}
			float diffY = theNpc->GetPos().y - thePlayer->GetPos().y;
			theNpc->SetPos_y(RESOLUTION_HEIGHT*2.15 - TILE_SIZE * 3 + diffY);
		}
	}

}
void CPlayState::ScanMap()
{

	int NoOfMob = 0;
	int NoOfCam = 0;
	//Loop through column

	for (short p = 0; p < theGlobal->theMap->getNumOfTiles_MapHeight(); ++p)
	{
		//Loop through row
		for (short q = 0; q < theGlobal->theMap->getNumOfTiles_MapWidth(); ++q)
		{
			int current = theGlobal->theMap->theScreenMap[p][q];
			switch (current) 
			{
			case CMap::SPAWN_MONSTER:
				NoOfMob++;
				break;
			case CMap::SPAWN_CAM:
			case CMap::SPAWN_CAM2:
			case CMap::SPAWN_CAM3:
			case CMap::SPAWN_CAM4:
				NoOfCam++;
				break;
				//WayPoint initing
			case CMap::PATH_1:
			case CMap::PATH_2:
			case CMap::PATH_3:
			case CMap::PATH_4:
			case CMap::PATH_5:
			case CMap::PATH_6:	
			case CMap::PATH_7:
			case CMap::PATH_8:
			case CMap::PATH_9:
			case CMap::PATH_10:
			case CMap::PATH_11:
			case CMap::PATH_12:
			case CMap::PATH_13:
			case CMap::PATH_14:
			case CMap::PATH_15:
			case CMap::PATH_16:	
			case CMap::PATH_17:
			case CMap::PATH_18:
			case CMap::PATH_19:
			case CMap::PATH_20:
				Paths[-(-current+CMap::PATH_1)].Points.push_back(Vector3D((float)(q*TILE_SIZE+LEFT_BORDER-theGlobal->theMap->mapOffset_x), (float)(p*TILE_SIZE+BOTTOM_BORDER-theGlobal->theMap->mapOffset_y)));
				//Paths[-(-current+CMap::PATH_1)].Points.push_back(Vector3D((float)(q*TILE_SIZE+LEFT_BORDER-theGlobal->theMap->mapOffset_x), (float)(p*TILE_SIZE+BOTTOM_BORDER-theGlobal->theMap->mapOffset_y)));
				break;
			}

		}
	}

	int path = 0;
	for (short i = 0; i < theGlobal->theMap->getNumOfTiles_MapHeight(); ++i)
	{
		//Loop through row
		for (short k = 0; k < theGlobal->theMap->getNumOfTiles_MapWidth(); ++k)
		{
			int current = theGlobal->theMap->theScreenMap[i][k];


			//Process Tiles
			switch (current) 
			{


			case CMap::SPAWN_MONSTER:



				if (NoOfMob > (int)GuardList.size())
				{
					//cout << NoOfMob  << " , " << GuardList.size() << endl;
					//Create new Enemy
					CGuard *temp = new CGuard; 
					temp->SelfInit();
					temp->SetPos(Vector3D((float)(k*TILE_SIZE+LEFT_BORDER-theGlobal->theMap->mapOffset_x), (float)(i*TILE_SIZE+BOTTOM_BORDER-theGlobal->theMap->mapOffset_y)));
					temp->SetPath(Paths[path]); 
					temp->SetTarget(thePlayer);
					//temp->SetWayPoints(); //Set Way Points for Enemy
					//cout << temp->GetPos().x << " , " <<  temp->GetPos().x << endl;

					GuardList.push_back(temp); 

					++path;
				}
				break;

			case CMap::SPAWN_CAM:

				if (NoOfCam > (int)SCamList.size())
				{
					//cout << NoOfMob  << " , " << GuardList.size() << endl;
					//Create new Enemy
					CSecurityCam *temp = new CSecurityCam; 
					temp->SelfInit(1);
					temp->SetPos(Vector3D((float)(k*TILE_SIZE+LEFT_BORDER-theGlobal->theMap->mapOffset_x), (float)(i*TILE_SIZE+BOTTOM_BORDER-theGlobal->theMap->mapOffset_y)));


					SCamList.push_back(temp); 

					//++path;
				}
				break;
			case CMap::SPAWN_CAM2:

				if (NoOfCam > (int)SCamList.size())
				{
					//cout << NoOfMob  << " , " << GuardList.size() << endl;
					//Create new Enemy
					CSecurityCam *temp = new CSecurityCam; 
					temp->SelfInit(2);
					temp->SetPos(Vector3D((float)(k*TILE_SIZE+LEFT_BORDER-theGlobal->theMap->mapOffset_x), (float)(i*TILE_SIZE+BOTTOM_BORDER-theGlobal->theMap->mapOffset_y)));


					SCamList.push_back(temp); 

					//++path;
				}
				break;
			case CMap::SPAWN_CAM3:

				if (NoOfCam > (int)SCamList.size())
				{
					//cout << NoOfMob  << " , " << GuardList.size() << endl;
					//Create new Enemy
					CSecurityCam *temp = new CSecurityCam; 
					temp->SelfInit(3);
					temp->SetPos(Vector3D((float)(k*TILE_SIZE+LEFT_BORDER-theGlobal->theMap->mapOffset_x), (float)(i*TILE_SIZE+BOTTOM_BORDER-theGlobal->theMap->mapOffset_y)));


					SCamList.push_back(temp); 

					//++path;
				}
				break;
			case CMap::SPAWN_CAM4:

				if (NoOfCam > (int)SCamList.size())
				{
					//cout << NoOfMob  << " , " << GuardList.size() << endl;
					//Create new Enemy
					CSecurityCam *temp = new CSecurityCam; 
					temp->SelfInit(4);
					temp->SetPos(Vector3D((float)(k*TILE_SIZE+LEFT_BORDER-theGlobal->theMap->mapOffset_x), (float)(i*TILE_SIZE+BOTTOM_BORDER-theGlobal->theMap->mapOffset_y)));


					SCamList.push_back(temp); 

					//++path;
				}
			case CMap::SPAWN_CAM5:

				if (NoOfCam > (int)SCamList.size())
				{
					//cout << NoOfMob  << " , " << GuardList.size() << endl;
					//Create new Enemy
					CSecurityCam *temp = new CSecurityCam; 
					temp->SelfInit(5);
					temp->SetPos(Vector3D((float)(k*TILE_SIZE+LEFT_BORDER-theGlobal->theMap->mapOffset_x), (float)(i*TILE_SIZE+BOTTOM_BORDER-theGlobal->theMap->mapOffset_y)));


					SCamList.push_back(temp); 

					//++path;
				}
				break;
			case CMap::SPAWN_CAM6:

				if (NoOfCam > (int)SCamList.size())
				{
					//cout << NoOfMob  << " , " << GuardList.size() << endl;
					//Create new Enemy
					CSecurityCam *temp = new CSecurityCam; 
					temp->SelfInit(6);
					temp->SetPos(Vector3D((float)(k*TILE_SIZE+LEFT_BORDER-theGlobal->theMap->mapOffset_x), (float)(i*TILE_SIZE+BOTTOM_BORDER-theGlobal->theMap->mapOffset_y)));


					SCamList.push_back(temp); 

					//++path;
				}
				break;
			}

		}
	}
} 

int CPlayState::get_menu_volume()
{
	return CMenuState::Instance()->myMenu->volume;
}

bool CPlayState::get_menu_sounds_muted()
{
	return CMenuState::Instance()->myMenu->mute_music;
}