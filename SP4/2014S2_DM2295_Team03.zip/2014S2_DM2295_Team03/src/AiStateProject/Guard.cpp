#include "Guard.h"
#include "PlayerInfo.h"

CGuard::CGuard(void)
{
	loot = false;
	isMoving = false;
	previousTime = 0;
	//Math::InitRNG();
	/*inventory = new Inventory();
	for(int i = 0; i < rand()%3 + 3; i++)
	{
		inventory->addItem(rand()%9+1);
	}
	inventory->addItem(7);
	inventory->setAllItemsToBeOld();*/
}


CGuard::~CGuard(void)
{
}

void CGuard::SelfInit(void)
{

	//RotateAngle = 0;
	//starting state
	CurrentState = PATROL;

	//Basic Setup
	Scale.Set(1.0f, 1.0f, 1.0f);
	Vel.Set(10.0f,10.0f,0.0f);
	Dir.Set(1.0f,0.0f,0.0f);
	Color.Set(1.0f, 1.0f, 1.0f);
	active = true;
	NeedRender = true;
	
	//Health and Damage
	Health.max = 100;
	Health.current = Health.max;
	Damage = 10;
	//sightchecking
	range = 200;
	disp = 0.4;
	m_iTileSize = TILE_SIZE;

	GuardSprite = new CSprite;
	GuardSprite->ImageInit(4, 1, 100);

	if( !LoadTGA( &(Texture[ 0 ]), "Texture/Tiles/Japan1.tga"))
		cout << "No hero texture" << endl;
	if( !LoadTGA( &(Texture[ 1 ]), "Texture/Tiles/Japan1.tga"))
		cout << "No hero texture" << endl;
	if( !LoadTGA( &(Texture[ 2 ]), "Texture/Tiles/Japan1up.tga"))
		cout << "No hero texture" << endl;
	if( !LoadTGA( &(Texture[ 3 ]), "Texture/Tiles/Japan1down.tga"))
		cout << "No hero texture" << endl;
	if( !LoadTGA( &(Texture[ 4 ]), "Texture/Tiles/rip.tga"))
		cout << "No hero texture" << endl;
	weapon = new CWeapon();
	weapon->Init();
	weapon->setCurrAmmo(-2);// inf ammo
	//weapon->setCurrEquipped("Pistol");//guard weapon
}

bool CGuard::Update(void)
{
	
	float dt = CGameTime::GetDelta();
	//cout << dt << endl;

	//decide whether to render or not
	if (Pos.x < LEFT_BORDER || Pos.x > RESOLUTION_WIDTH-LEFT_BORDER-TILE_SIZE*3 || 
		Pos.y < BOTTOM_BORDER || Pos.y > RESOLUTION_HEIGHT-BOTTOM_BORDER+TILE_SIZE)
	{
		NeedRender = false;
	}
	else
	{
		NeedRender = true;
	}

	//health system
	if (Health.current <= 0)
	{
		if (enemy == NULL)//this type of code will only play once
			enemy = theGlobal->SoundEngine->play2D("Sound/ugh.mp3", false, true);
		if (enemy->getIsPaused() == true)
			enemy->setIsPaused(false);
		//theGlobal->SoundEngine->play2D("bullet hit body.mp3", false, true);
		if(Health.no > 0)
		{
			Health.current = Health.max;
			Health.no -= 1;
		}
		else
		{
			//active = false;
		}
	}

	else
	{
		enemy = NULL;
		//individual
		IndividualAction();


		//TeamAction();

		//Act on the current state
		switch (CurrentState) //Switch to decide dir
		{
		case ATTACK:
			{
				//int currentTime = glutGet(GLUT_ELAPSED_TIME);
				//int timeInterval = currentTime - previousTime;

				//if(timeInterval > 1000)
				//{
				//	Dir = Vector3D();		//stop movement
				//	if(Player->getHealth().current > 0)
				//		Player->setCurrentHealth(Player->getHealth().current - Damage);
				//	//attack
				//	previousTime = currentTime;
				//}
				
			}
			break;

		case CHASE:
			{
				Dir = Pos - Player->GetPos();
			}
			break;

		case PATROL:
			{
				WayPointDir(); //follow way point
			}
			break;

		case RETREAT:
			{
				Dir = (Pos - Player->GetPos()).negative(); //run away
				//only needed if using msgboard
				//CurrentState = IDLE;			//reset to idle if not retreating alr
			}
			break;
		case IDLE:	
			{
				//do nothing
			}
			break;
		}
		if (theGlobal->Collided(Pos-Vector3D(0,5,0), true, false, false, false, 
			theGlobal->theMap,theGlobal->theMap->mapOffset_x, theGlobal->theMap->mapOffset_y))
		{
			switch (CurrentState) //Switch to decide dir
			{ 
			case CHASE:
				{
				//Dir = Pos - Player->GetPos();
				if(Dir.y > 0)
					Dir.y = 0;
				break;
				}
			case PATROL:
				{
				//WayPointDir();
				if(Dir.y > 0)
					Dir.y = 0;
				break;
				}
			case RETREAT:
				{
				//Dir = (Pos - Player->GetPos()).negative();
				if(Dir.y > 0)
					Dir.y = 0;
				break;
				}
			}
		}
		if (theGlobal->Collided(Pos+Vector3D(0,5,0), false, true, false, false, 
			theGlobal->theMap, theGlobal->theMap->mapOffset_x,theGlobal->theMap->mapOffset_y))
		{
			switch (CurrentState) //Switch to decide dir
			{ 
			case CHASE:
				{
				//Dir = Pos - Player->GetPos();
				if(Dir.y < 0)
					Dir.y = 0;
				break;
				}
			case PATROL:
				{
				//WayPointDir();
				if(Dir.y < 0)
					Dir.y = 0;
				break;
				}
			case RETREAT:
				{
				//Dir = (Pos - Player->GetPos()).negative();
				if(Dir.y < 0)
					Dir.y = 0;
				break;
				}
			}
		}
		Vector3D posL; //Fixes the Collision 
		posL.Set(Pos.x-7, Pos.y); //Buffer of 7
		if (theGlobal->Collided(posL, false, false, true, false, 
			theGlobal->theMap, theGlobal->theMap->mapOffset_x, theGlobal->theMap->mapOffset_y))
		{
			switch (CurrentState) //Switch to decide dir
			{ 
			case CHASE:
				{
				//Dir = Pos - Player->GetPos();
				if(Dir.x > 0)
				Dir.x = 0;
				break;
				}
			case PATROL:
				{
				//WayPointDir();
				if(Dir.x > 0)
				Dir.x = 0;
				break;
				}
			case RETREAT:
				{
				//Dir = (Pos - Player->GetPos()).negative();
				if(Dir.x > 0)
					Dir.x = 0;
				break;
				}
			}

			Vector3D posL; //Fixes the Collision 
			posL.Set(Pos.x-7, Pos.y); //Buffer of 7
		}
		Vector3D posR; //Fixes the Collision 
		posR.Set(Pos.x+7, Pos.y); //Buffer of 7
		if (theGlobal->Collided(posR, false, false, false, true, 
			theGlobal->theMap, theGlobal->theMap->mapOffset_x, theGlobal->theMap->mapOffset_y))
		{
			switch (CurrentState) //Switch to decide dir
			{ 
			case CHASE:
				{
				//Dir = Pos - Player->GetPos();
				if(Dir.x < 0)
				Dir.x = 0;
				break;
				}
			case PATROL:
				{
				//WayPointDir();
				if(Dir.x < 0)
				Dir.x = 0;
				break;
				}
			case RETREAT:
				{
				//Dir = (Pos - Player->GetPos()).negative();
				if(Dir.x < 0)
					Dir.x = 0;
				break;
				}
			}
		}
		//if(Dir.GetMagnitude() == 0 && CurrentState == CHASE)
		//{
		//	CurrentState = PATROL;
		//	WayPointDir(); //follow way point
		//}
		//if(CurrentState != ATTACK)//cause dir = 0 at attack
		//{
		if(Dir.x != 0 || Dir.y != 0)
			Dir.normalizeVector3D();	//normalise dir before using	
		//}
		
		switch (CurrentState) //Switch to decide dir
		{
		case ATTACK:
			weapon->Attack(Dir.negative(),Pos,false);
			break;
		case CHASE:
			if(Dir == (Pos - Player->GetPos()).normalized() && (Pos - Player->GetPos()).GetMagnitude() > 70)
			weapon->Attack(Dir.negative(),Pos,false);
			break;
		}
		/*if(CurrentState == CHASE || PrevState == CHASE || CurrentState == ATTACK || PrevState == ATTACK)
			*/
		Pos = Pos - Vel * Dir * dt;	//move character
	}
	//cout << CurrentState << endl;
	//	cout << dt << endl;
	//cout << CurrentState << endl;
	//cout << active << endl;
	if(Dir.x < 0)
		weapon->SetAnimationInvert( false );
	else
		weapon->SetAnimationInvert( true );
	weapon->SetPos_x(Pos.x);
	weapon->SetPos_y(Pos.y);

	return true;
}

void CGuard::IndividualAction(){
	//can be lua-ed
	float distbetween = (Pos - Player->GetPos()).GetMagnitude();

	if ( distbetween < 35 )
	{
		CurrentState = ATTACK;

		weapon->setCurrEquipped("Knife");
	}
	else if ( distbetween < 300 )
	{
		if (CurrentState != COLLIDED_D && CurrentState != COLLIDED_U
		&& CurrentState != COLLIDED_L && CurrentState != COLLIDED_R)
		{
			CurrentState = CHASE;
			weapon->setCurrEquipped("Pistol");
		}
	}
	else
	{
		//random between partrol and idle
		CurrentState = PATROL;
	}


}

/*
void CGuard::TeamAction(){
	/*
	for(unsigned i = 0; i < CGoodies::theArrayOfGoodies.size(); ++i)
	{
		CGoodies *go = CGoodies::theArrayOfGoodies[i];
	}
	
	if(Health.current < 50) // health bar below 1x
	{
		//Send help message
		CMessageBoard::MsgInfo* tempMsg = new CMessageBoard::MsgInfo;
		tempMsg->CharID = ID;
		tempMsg->message = CMessageBoard::ID_SAVEME;
		theGlobal->theMsgBoard->SetMSG( tempMsg );
	}
	/*
	if(Target->State == OBJECT_STATE::SKILLING)
	{
		//Send help message
		CMessageBoard::MsgInfo* tempMsg = new CMessageBoard::MsgInfo;
		tempMsg->CharID = ID;
		tempMsg->message = CMessageBoard::ID_RETREAT;
		theGlobal->theMsgBoard->SetMSG( tempMsg );
	}
	

	vector<CMessageBoard::MsgInfo*> MsgInfoList = theGlobal->theMsgBoard->GetMSGList();

	if( MsgInfoList.size() != 0){// check if there is message
		for(unsigned x = 0; x < MsgInfoList.size(); ++x)
		{
			CGoodies *go = NULL;
			CMessageBoard::MsgInfo* msg = MsgInfoList[x];

			if(msg->message !=  CMessageBoard::ID_NOMSG || msg->message != NULL )
				go = CGoodies::theArrayOfGoodies[msg->CharID-1]; //using the id of the sender to find him
			
			if(go){
				if (go->GetItem(TEAMNO) == TeamNo)
				{
					switch(msg->message)
					{
					case CMessageBoard::ID_NOMSG:
						{

						}
						break;
					case CMessageBoard::ID_ATTACKSTUNENEMY:
						{
							//inverse = -1;
						}
						break;
		
					case CMessageBoard::ID_PROTECTME:
						{
							//inverse = -1;
						}
						break;

					case CMessageBoard::ID_RETREAT:
						{
							//inverse = -1;
							for(unsigned i = 0; i < CGoodies::theArrayOfGoodies.size(); ++i)
							{
								CGoodies *go = CGoodies::theArrayOfGoodies[i];
								//check for boss
								if(go->Object == CGoodies::ENEMY && go->GetItem(ITEM_ID::TEAMNO) != TeamNo)
								{
									//set target as boss
									Target = go;
									break;
								}
							}


							if(Target->GetItem(CVariable::TEAMNO) != this->TeamNo)
							{
								CurrentState = RETREAT;
							}
						}
						break;
					case CMessageBoard::ID_SAVEME:
						{
							//CurrentState = RETREAT; //
			
						}
						break;
					}
				}
			}
		}
	}
}
*/
int CGuard::GetState()
{
	return CurrentState;
}
void CGuard::Render()
{
	//drawLines(Pos,OwnPath.getCurrentPoint());

	if(Health.current > 0)
	DrawHealthBar(Health.current, Health.max ,  Pos.x-110 ,Pos.y-20, Vector3D(1,0,0));

	if (CurrentState== IDLE || !active)
	{
		if (GetAnimationCounter() != 1)
			SetAnimationCounter(1);
	}

	SetAnimationCounter( GetAnimationCounter() + 1);
	if (GetAnimationCounter()> 3)
			SetAnimationCounter( 0 );
	//cout << Pos.x << " , " << Pos.y << endl; 
	float i = Dir.GetMagnitude2D();
	if (Dir.x < 0 && Dir.GetMagnitude2D() >= 1)
		SetAnimationInvert(true);
	else if (Dir.x > 0 && Dir.GetMagnitude2D() >= 1)
		SetAnimationInvert(false);
	//Info();
	currIMG = Texture[0];
	if(Health.current <= 0)
	{
		currIMG = Texture[4];
	}
	else if(Dir.y < 0 && Dir.y*Dir.y >  Dir.x*Dir.x)
		currIMG = Texture[3];
	else if(Dir.y > 0 && Dir.y*Dir.y >  Dir.x*Dir.x)
		currIMG = Texture[2];
	if(NeedRender == true){
		glPushMatrix();
		glTranslatef((float)(Pos.x+TILE_SIZE*0.5), (float)(Pos.y+TILE_SIZE*0.5), 0);
		GuardSprite->render(currIMG,GetAnimationCounter(),GetAnimationInvert());
		glPopMatrix();
		if(CurrentState == CHASE || PrevState == CHASE || CurrentState == ATTACK || PrevState == ATTACK)
		{
			if(Health.current > 0)
				weapon->Renderweap();
		}
	}
	weapon->Update();

	glPushMatrix();

	glColor3f(Color.x,Color.y,Color.z);

	drawLines(mid,leftPoint); 
	drawLines(mid,rightPoint); 
	drawLines(leftPoint,rightPoint);

	glColor3f(1,1,1);
	glPopMatrix();
}


void CGuard::Info(){
	//DrawHealthBar(Health.current, Health.max ,  Pos.x-110 ,Pos.y-40);

	glPushMatrix();
	//glScalef(0.5,0.5,1);

	printw(1,Pos.x ,Pos.y-40 , 0 , "Health: %d", Health.no);
	//printw(1,Pos.x-35 ,Pos.y-40 , 0 , "%d." , ID);
	//printw(1,Pos.x-70 ,Pos.y-40 , 0 , "%d." , Target->GetID());

	int repos = 35;

	std::string tempState;

	switch(CurrentState)
	{		
		case ATTACK:
		{
			tempState = "ATTACK STATE";
			//printw(Pos.x-30 ,Pos.y+repos ,0,"ATTACK STATE");
			//StateTexture(Atk[0]);
		}
			break;

		case CHASE:
		{
			tempState = "CHASING STATE";
			//printw(Pos.x-30 ,Pos.y+repos ,0,"CHASING STATE");
		}
			break;

		case PATROL:
		{
			tempState = "PATROL STATE";
		}
			break;
		case IDLE:
		{
			tempState = "IDLE STATE";
			//printw(Pos.x-30,Pos.y+repos,0,"IDLE STATE");
			//StateTexture(Def[0]);
		}
			break;
		default:
		{
			tempState = "NO STATE";
		}
		break;
	}
	//printw(0,Pos.x-30,Pos.y+repos,0,"%s", tempState);

	glPopMatrix();
}

void CGuard::SetItem(ITEM_ID item_id , int SetItem)
{
	/*
	switch (item_id)
	{
		case TEAMNO	:
		{
			TeamNo = SetItem;
		}
		break;
	}
	*/
}

int CGuard::GetItem(ITEM_ID item_id)
{
	/*
	switch (item_id)
	{
		case TEAMNO	:
		{
			return TeamNo;
		}
		break;
	}
	*/
	return 0;
}

void CGuard::WayPointDir()
{
	//Vector3D Point = Vector3D(OwnPath.getCurrentPoint().getX() ,OwnPath.getCurrentPoint().getY() , OwnPath.getCurrentPoint()->getZ() );

	Vector3D DistFromPoint =  Pos - OwnPath.getCurrentPoint()  ;
		
	//Direction toward target
	Dir = DistFromPoint;
	

	if ( DistFromPoint.GetMagnitude2D() < 1 )
		OwnPath.IndexPlus();

}

bool CGuard::SightChecking()
{
	//Vector3D Checkdir = Vector3D(1-Checkdisp,-1+Checkdisp); 
	mid =  Vector3D( (Pos.x + (float)(m_iTileSize*0.5)) ,   (Pos.y  + (float)(m_iTileSize*0.5)) );
	dirPoint = Vector3D( (mid.x + range* Dir.x) , (mid.y + range * Dir.y)  );

	//cout << Dir.x << " , " << Dir.y << endl;

	if(Dir.y > 0 && Dir.x > 0 ){ // +X , + Y (dir at top right corner)
		leftPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y - disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y - disp) )  );
		//cout << "top right" << endl;
	}
	else if (Dir.y > 0 && Dir.x < 0) // -X , + Y (top left)
	{ 

		leftPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y - disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y + disp) )  );
	
		//cout << "top left" << endl;
	}

	else if(Dir.y > 0 && Dir.x > 0 ){ // +X , -Y (dir at bot right corner)
		leftPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y + disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y + disp) )  );
		//cout << "bot right" << endl;
	}
	else if (Dir.y > 0 && Dir.x < 0) // -X , + Y (bot left )
	{ 
				leftPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y + disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y - disp) )  );
		//cout << "bot left" << endl;
	}


	if (Dir.y == -1 && Dir.x == 0) // -X , + Y (down)
	{ 
		leftPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y + disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y + disp) )  );
		//cout << "up" << endl;
	}
	else if(Dir.y == 1 && Dir.x == 0 ) // +X , + Y (up)
	{ 
		leftPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y - disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y - disp) )  );
		//cout << "down" << endl;
	}

	else if (Dir.y == 0 && Dir.x == -1) // -X , + Y (left)
	{
		leftPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y - disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x + disp) ) , (mid.y + range * (Dir.y + disp) )  );
		//cout << "left" << endl;
	}
	else if (Dir.y == 0 && Dir.x == 1) // -X , + Y (right)
	{ 
		leftPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y + disp) )  );
		rightPoint = Vector3D( (mid.x + range* (Dir.x - disp) ) , (mid.y + range * (Dir.y - disp) )  );
	
		//cout << "right" << endl;
	}

	if( Vector3D::PointInTriangle(PlayerPos,mid,leftPoint,rightPoint) )
	{
		Color = Vector3D(GREEN);
		return true;
	}
	else
	{
		Color = Vector3D(RED);
		return false;
	}
	return false;


}