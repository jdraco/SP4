DO FOLLOWING STEPS FIRST BEFORE RUNNING exe/AiStateProject.exe

Right Click "AiStateProject.exe" > Properties > Compatibility tab > Tick "Run this program in compatibility mode for:" > Select "Windows XP (Service Pack 3) under dropdown menu > Ok